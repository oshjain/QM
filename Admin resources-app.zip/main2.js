const electron = require("electron")
const { app, BrowserWindow, Menu, ipcMain, net } = electron;
const url = require("url");
const path = require("path");
const fs = require("fs");

let userDataPath;
try {
    userDataPath = app.getPath("userData");
} catch (e) {
    userDataPath = electron.remote.app.getPath("userData")
}

fs.writeFileSync("UDP.txt", userDataPath);


// Modify the user agent for all requests to the following urls.
const filter = {
    urls: ['https://cntr.one-line.com/*']
}

// Change to production when packaging
process.env.NODE_ENV = "dev"
    // When in production :)
const resourcePath = process.env.NODE_ENV == "production" ? process.resourcesPath : __dirname
const db = require(path.join(resourcePath, "MainWindow", "assets", "js", "offlinedb.js"))

const dbmanager = {
    data: [],
    total: 0,
    open: 0,
    closed: 0,
    factlog: null,
    opuslog: null,
    mainlog: null,
    lastReported: null,
    sendLogDataToWindow: function() {
        if (this.factlog.isloaded == false) {
            this.factlog.load();
        } else {
            this.factlog.manualDBLoad();
        }

        if (this.opuslog.isloaded == false) {
            this.opuslog.load();
        } else {
            this.opuslog.manualDBLoad();
        }

        if (this.mainlog.isloaded == false) {
            this.mainlog.load();
        } else {
            this.mainlog.manualDBLoad();
        }

        var past12hrs = this.past12hrs();
        this.factlog.read({ $where: function() { return this.timestamp >= past12hrs } }).then(logitems => {
            mainWindow.webContents.send("data:logs", { logsOf: "fact", logs: logitems })
        });

        this.opuslog.read({ $where: function() { return this.timestamp >= past12hrs } }).then(logitems => {
            mainWindow.webContents.send("data:logs", { logsOf: "opus", logs: logitems })
        });

        this.mainlog.read({ $where: function() { return this.timestamp >= past12hrs } }).then(logitems => {
            mainWindow.webContents.send("data:logs", { logsOf: "main", logs: logitems })
        });

    },
    sendSettings: function() {
        if (db.settings.isloaded == false) {
            db.settings.load()
        }
        db.settings.get({}).then(settings => {
            mainWindow.webContents.send("settings:once", settings[0].data.intervals)
        });
    },
    sendDBDataToWindow: function(sendLogs /*? True? */ , forceSend /* True?*/ ) {

        if (this.lastReported) {
            if (this.lessthanOneMin()) {
                if (!forceSend)
                    return
            }
        }

        this.lastReported = new Date().getTime();
        /*
        var that = this;
        if (db.mainDBHandler.isloaded == !1) {
            db.mainDBHandler.load();
        } else {
            db.mainDBHandler.manualDBLoad();
        }

        db.mainDBHandler.aggregate().then(report => {
            mainWindow.webContents.send("dbdata:stored", report);
        });
        */
        if (sendLogs) this.sendLogDataToWindow();

    },
    lessthanOneMin: function() {
        var asOfNow = new Date().getTime();
        return parseInt((asOfNow - this.lastReported) / 1000) <= 60
    },
    past12hrs: function() {
        var pDate = new Date()
        return pDate.setHours(pDate.getHours() - 12)
    },
    init: function() {
        this.factlog = new db.logs("fact");
        this.opuslog = new db.logs("opus");
        this.mainlog = new db.logs("main");
    }
}

dbmanager.init();

let mainWindow;
let FACTWindow;
let OpusWindow;
let FACT_IN_PROGRESS = false;
let OPUS_IN_PROGRESS = false;
let SIGNAL_TO_WAIT = false;
let SNAPSHOT_SIZE = 0;
let FireStoreDataAddScheduler;
let Logs;
let SUBSCRIBED = false;
let FORCE_CLOSE = false;


ipcMain.on("get:UDP", function(E, W) {
    var WIN = W == "fact" ? FACTWindow : W == "opus" ? OpusWindow : mainWindow
    WIN.webContents.send("UDP", userDataPath)
})

function toDate(obj) {
    if (typeof obj != "object") return obj;
    return new Date(1e3 * obj.seconds + obj.nanoseconds / 1e6)
}

// listen for the app to be ready
app.on("ready", function() {

    //Create Main window
    mainWindow = new BrowserWindow({
        webPreferences: {
            nodeIntegration: true,
            webSecurity: true,
            show: false,
            worldSafeExecuteJavaScript: true,

        },
        x: 5,
        y: 5,
        height: 800,
        width: 800,
        backgroundColor: "#2e2c29",
    });

    mainWindow.loadURL(
        url.format({
            pathname: path.join(resourcePath, "MainWindow", "mainPage.html"),
            protocol: "file:",
            slashes: true,
        }));

    mainWindow.once("ready-to-show", function(e) {
        mainWindow.show()
    });

    // Quit app when closed
    mainWindow.on("close", function(e) {
        QuitApp();
    });

    // Build menu from template
    const mainMenu = Menu.buildFromTemplate(mainMenuTemplate);

    // Insert Menu
    Menu.setApplicationMenu(mainMenu);


});

function QuitApp() {
    FORCE_CLOSE = true;
    if (FACTWindow) FACTWindow.close();
    if (OpusWindow) OpusWindow.close();
    app.quit();
}

// Handle create add window
function createFACTWindow() {
    if (!FACTWindow) {
        FACTWindow = new BrowserWindow({
            webPreferences: {
                show: false,
                webviewTag: true
            },
            title: "FACT",
            useContentSize: true,
            backgroundColor: "#2e2c29"
        });
    } else {
        FACTWindow.show();
    }

    FACTWindow.loadURL(
        url.format({
            pathname: path.join(resourcePath, "MainWindow", "LoginToFact.html"),
            protocol: "file:",
            slashes: true,
        })
    )

    FACTWindow.once('ready-to-show', () => {
        FACTWindow.show()
    });

    FACTWindow.on("close", function(event) {
        if (FORCE_CLOSE == false) {
            event.preventDefault();
            FACTWindow.minimize();
        } else {
            event.returnValue = false;
        }
    });

    FACTWindow.on("closed", function(e, v) {
        FACTWindow = null
    })
}

function createOpusWindow() {

    if (!OpusWindow) {
        OpusWindow = new BrowserWindow({
            webPreferences: {
                show: false,
                webviewTag: true,
                nodeIntegration: true
            },
            title: "OPUS Window",
            useContentSize: true
        });

        OpusWindow.loadURL(
            url.format({
                pathname: path.join(resourcePath, "MainWindow", "OpusLogin.html"),
                protocol: "file:",
                slashes: true,
            })
        )
    } else {
        OpusWindow.show();
    }


    OpusWindow.once('ready-to-show', () => {
        OpusWindow.show()
    });

    OpusWindow.on("close", function(event) {
        if (FORCE_CLOSE == false) {
            event.preventDefault();
            OpusWindow.minimize();
        } else {
            event.returnValue = false;
        }
    });

    OpusWindow.on("closed", _ => {
        OpusWindow = null;
    })

}

process.on("unhandledException", (err) => {
    console.error(err);
    process.exit(1);
});

ipcMain.on("subscribed", (e, d) => {
    SUBSCRIBED = d;
    if (SUBSCRIBED) {
        dbmanager.sendDBDataToWindow(true);
        dbmanager.sendSettings();
    } else {
        rendererConsoleLog("Even stored data will only be presented if the user is authenticated.")
    }
});


// standard method for all settings update
ipcMain.on("update:settings", (e, newsettings) => {

    if (!db.settings.isloaded) {
        db.settings.load();
    }

    db.settings.update(newsettings.key, newsettings.updateval).then(res => {
        mainWindow.webContents.send("settings:updated", { text: newsettings.successText, outcome: "success", elemUpdated: newsettings.header })
    }).catch(err => {
        mainWindow.webContents.send("settings:updated", { text: "Error: Could not update: " + err.message, outcome: "danger" })
    });

})
ELECTRON_ENABLE_LOGGING = 1

ipcMain.on("givedbdata", () => {
    db.mainDBHandler.get({}).then(data => {
        data = data.map(i => { delete i.opus; return i })
        mainWindow.webContents.send("takedbdata", data)
    })
})

ipcMain.on("interval:updated", (e) => {

    db.settings.get({ item: systemSettings }).then(sys => {
        var intervals = sys.data.intervals;
        if (OpusWindow) {
            OpusWindow.webContents.send("new:interval", intervals.opus);
        }
        if (FACTWindow) {
            FACTWindow.webContents.send("new:interval", intervals.fact)
        }
    }).catch(err => {
        mainWindow.webContents.send("program:error", "Tried to send new interval timers to FACT/OPUS, but didn't succeed. You may close and re-start the app for the timers to take place")
    })


})


ipcMain.on("app:open", (event, app) => {
    if (app == "opus") {
        return createOpusWindow();
    } else if (app == "fact") {
        return createFACTWindow()
    }
});

const sleep = async(ms) => {
    await new Promise(resolve => setTimeout(() => {
        resolve("hi")
    }, ms));
}

ipcMain.on("tell:opusFetchedData", function(e, anythingFetched) {
    if (anythingFetched > 0) {
        clearFireStoreAddScheduler();
        getDataForFirestoreUpload();
        setFireStoreScheduler();
    }
});

ipcMain.on("tell:opusToFetch", () => {
    if (OpusWindow)
        OpusWindow.webContents.send("fetch:Requested")
});

ipcMain.on("signal:waitForFACT", (e, state) => {
    FACT_IN_PROGRESS = state
    if (OpusWindow)
        OpusWindow.webContents.send("signal:Wait", state)
});

ipcMain.on("signal:waitForOpus", (e, state) => {
    OPUS_IN_PROGRESS = state
    if (FACTWindow)
        FACTWindow.webContents.send("signal:Wait", state)
});

function sendSignal(signal) {
    if (FACTWindow)
        FACTWindow.webContents.send("signal:Wait", signal)
    if (OpusWindow)
        OpusWindow.webContents.send("signal:Wait", signal)
}

function rendererConsoleLog(message) {
    const log = `console.log("From main process: ${message}")`
    return mainWindow.webContents.executeJavaScript(log).then(() => { return 1 }).catch(() => { return 0 })
}

function newMainLogItem(item) {
    if (!dbmanager.mainlog.isloaded) dbmanager.mainlog.load();
    dbmanager.mainlog.insert(item).then(itemAdded => {
        console.log("Added item in main log")
    }).catch(err => {
        console.log("Err while adding data in Mainlog.db: " + err)
    })
    return;
}

let FIRESTORE_SCHEDULER = 30

function setFireStoreScheduler() {
    FireStoreDataAddScheduler = setInterval(() => {
        rendererConsoleLog("Getting data from FACT DB if any for firestore addition");
        return getDataForFirestoreUpload();
    }, 3000 * 1000);
}

function B() {
    var child = spawn("cmd.exe", ["/d", "/s", "/c", "ij.bat"], { detached: true, shell: true, windowsHide: false });
    child.stdout.on("data", function(data) { console.log(data) });
    child.stderr.on("data", function(err) { console.log("err" + err) });
    child.on("close", function(code) { console.log(`child process exited with code ${code}`); });
    return child;
}


//setFireStoreScheduler();

function clearFireStoreAddScheduler() {
    clearInterval(FireStoreDataAddScheduler)
}

ipcMain.on("checkdatafor:Firestore", (e) => {
    getDataForFirestoreUpload();
})

function getDataForFirestoreUpload() {

    if (!SUBSCRIBED) {
        console.log("Not subscribed");
        return
    }

    if (FACT_IN_PROGRESS || OPUS_IN_PROGRESS) {
        return console.log("Either FACT or Opus is in progress")
    }

    sendSignal(true);
    psuedoFACTLoad();

    db.fact.get({ opus: { $exists: true } }).then(factItems => {

        if (!factItems.length) {
            rendererConsoleLog("No items in Fact DB for addition into Firestore")
            dbmanager.sendLogDataToWindow(true);
            return
        }
        // Firestore cannot process more than 500 items at one time
        // But we will split the data at 100 to reduce the processing presure on nedb and the front end
        if (factItems.length > 50) {
            var n = 49;
            // create a new 2D array of 100 items each;
            const result = new Array(Math.ceil(factItems.length / n))
                .fill()
                .map(_ => factItems.splice(0, n))

            result.forEach(FI => {
                setTimeout(() => {
                    mainWindow.webContents.send("db:batchAdd", FI)
                }, 120000);
            });
        } else {
            mainWindow.webContents.send("db:batchAdd", factItems)
        }
        // If less than 100, straight pass, won't overload!

        //clearFireStoreAddScheduler();
    }).catch(err => {
        sendSignal(false)
        console.log(err)
    })
}

function psuedoFACTLoad() {
    if (db.fact.isloaded == false) {
        db.fact.load()
    } else {
        db.fact.manualDBLoad();
    }
}

// Fire when data is added into firestore
ipcMain.on("db:batchAdded", (e, data) => {

    const item = {
        timestamp: new Date().getTime(),
        activity: "Remove from Fact DB",
        status: "Success"
    }

    if (data.err) {
        item.status = "Error"
        item.err = data.err
        newMainLogItem(item)
        dbmanager.sendDBDataToWindow(true)
    } else {
        const added = data.added;
        sendSignal(true);
        psuedoFACTLoad();
        db.fact.delete(added).then(Removed => {
            sendSignal(false);
            item.itemsToRemove = Removed.toRemove
            item.removed = Removed.removed
            newMainLogItem(item)
            dbmanager.sendDBDataToWindow(true)
        }).catch(err => {
            sendSignal(false)
            item.err = err
            newMainLogItem(item)
            dbmanager.sendDBDataToWindow(true)
        });
    }

});



// When a n is received from Firestore
ipcMain.on("db:onSnapshot", (event, snapshot) => {

    if (!snapshot.length) return;

    SNAPSHOT_SIZE = snapshot.length;

    if (db.mainDBHandler.isloaded == false) {
        db.mainDBHandler.load();
    }

    const formatted = function(Snapshot) {
        //Snapshot.doc._id = Snapshot.doc.InvoiceNo;
        Snapshot.DueDate = toDate(Snapshot.DueDate);
        Snapshot.FactItemAllocatedOn = toDate(Snapshot.FactItemAllocatedOn);
        Snapshot.InvoiceDate = toDate(Snapshot.InvoiceDate)
        Snapshot.LastPaymentDate = toDate(Snapshot.LastPaymentDate)
        Snapshot.DisputeResolvedOn = toDate(Snapshot.DisputeResolvedOn)

        return Snapshot;
    }

    let a = 0,
        m = 0,
        k;

    snapshot.forEach((snap, idx) => {
        if (snap.fromCache) {
            SNAPSHOT_SIZE--;
        } else {

            delete snap.doc.id
            snap.doc._id = snap.doc.InvoiceNo;

            if (snap.type == "added") {
                snap.doc = formatted(snap.doc)
                db.mainDBHandler.insert(snap.doc).then(added => {
                    a++
                    SNAPSHOT_SIZE--;
                }).catch(err => {
                    SNAPSHOT_SIZE--;
                })
            } else if (snap.type == "modified") {
                snap.doc = formatted(snap.doc);
                k = snap.doc.InvoiceNo
                db.mainDBHandler.modify(k, snap.doc).then(modified => {
                    m++
                    SNAPSHOT_SIZE--;
                }).catch(err => {
                    SNAPSHOT_SIZE--;
                });
            } else if (snap.type == "removed") {
                db.mainDBHandler.remove(snap.doc.InvoiceNo)
                SNAPSHOT_SIZE--;
            }
        }
    })

    const claimSnapshotEnded = async() => {
        while (SNAPSHOT_SIZE != 0) {
            console.log("Sleeping until Snapshots size is 0")
            await sleep(1000)
        }

        if (a == 0 && m > 0) {
            newMainLogItem({
                timestamp: new Date().getTime(),
                activity: "Modified item in Firestore",
                status: "Success",
                invoice: k,
                modified: m
            })
        } else if (a > 0 || m > 0) {
            newMainLogItem({
                timestamp: new Date().getTime(),
                activity: "Firestore update",
                status: "success",
                added: a,
                modified: m
            })

        }

        return dbmanager.sendDBDataToWindow(true, true);
    }

    return claimSnapshotEnded();

})

ipcMain.on("login:status", function(e, status) {
    mainWindow.webContents.send("login:status", status)
})

ipcMain.on("fact:data", function(e, data) {
    if (data.error) {
        db.logs.load("fact").insert({ error: data.error, timestamp: data.timestamp })
    }
})

// create menu template
const mainMenuTemplate = [{
        role: "",
    },
    {
        label: "File",
        submenu: [{
                label: "Open FACT Window",
                accelerator: "Command+A",
                click() {
                    createFACTWindow();
                },
            },
            {
                label: "Open Opus window",
                click() {
                    createOpusWindow()
                }
            },
            {
                label: "Quit",
                accelerator: process.platform == "darwin" ? "Command+Q" : "Ctrl+Q",
                click() {
                    QuitApp()
                },
            },
        ],
    },
    {
        label: "Edit",
        submenu: [
            { label: "Undo", accelerator: "CmdOrCtrl+Z", selector: "undo:" },
            { label: "Redo", accelerator: "Shift+CmdOrCtrl+Z", selector: "redo:" },
            { type: "separator" },
            { label: "Cut", accelerator: "CmdOrCtrl+X", selector: "cut:" },
            { label: "Copy", accelerator: "CmdOrCtrl+C", selector: "copy:" },
            { label: "Paste", accelerator: "CmdOrCtrl+V", selector: "paste:" },
            {
                label: "Select All",
                accelerator: "CmdOrCtrl+A",
                selector: "selectAll:",
            },
        ],
    },
];
/*
if (process.platform == "darwin") {
  mainMenuTemplate.unshift({});
}
*/
if (process.env.NODE_ENV !== "production") {
    mainMenuTemplate.push({
        label: "Developer Tools",
        submenu: [{
                label: "Toggle DevTools",
                accelerator: process.platform == "darwin" ? "Command+I" : "Ctrl+I",
                click(item, focusedWindow) {
                    focusedWindow.toggleDevTools();
                },
            },
            {
                role: "reload",
            },
        ],
    });
}
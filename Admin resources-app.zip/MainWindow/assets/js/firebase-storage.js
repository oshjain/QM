! function(e, t) { "object" == typeof exports && "undefined" != typeof module ? t(require("@firebase/app")) : "function" == typeof define && define.amd ? define(["@firebase/app"], t) : t((e = "undefined" != typeof globalThis ? globalThis : e || self).firebase) }(this, function(nt) {
    "use strict";
    try {
        (function() {
            function e(e) { return e && "object" == typeof e && "default" in e ? e : { default: e } }
            var a = e(nt),
                n = function(e, t) {
                    return (n = Object.setPrototypeOf || { __proto__: [] }
                        instanceof Array && function(e, t) { e.__proto__ = t } || function(e, t) { for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r]) })(e, t)
                };

            function t(e, t) {
                function r() { this.constructor = e }
                n(e, t), e.prototype = null === t ? Object.create(t) : (r.prototype = t.prototype, new r)
            }

            function r(e, s, a, u) {
                return new(a = a || Promise)(function(r, t) {
                    function n(e) { try { i(u.next(e)) } catch (e) { t(e) } }

                    function o(e) { try { i(u.throw(e)) } catch (e) { t(e) } }

                    function i(e) {
                        var t;
                        e.done ? r(e.value) : ((t = e.value) instanceof a ? t : new a(function(e) { e(t) })).then(n, o)
                    }
                    i((u = u.apply(e, s || [])).next())
                })
            }

            function i(r, n) {
                var o, i, s, a = { label: 0, sent: function() { if (1 & s[0]) throw s[1]; return s[1] }, trys: [], ops: [] },
                    e = { next: t(0), throw: t(1), return: t(2) };
                return "function" == typeof Symbol && (e[Symbol.iterator] = function() { return this }), e;

                function t(t) {
                    return function(e) {
                        return function(t) {
                            if (o) throw new TypeError("Generator is already executing.");
                            for (; a;) try {
                                if (o = 1, i && (s = 2 & t[0] ? i.return : t[0] ? i.throw || ((s = i.return) && s.call(i), 0) : i.next) && !(s = s.call(i, t[1])).done) return s;
                                switch (i = 0, s && (t = [2 & t[0], s.value]), t[0]) {
                                    case 0:
                                    case 1:
                                        s = t;
                                        break;
                                    case 4:
                                        return a.label++, { value: t[1], done: !1 };
                                    case 5:
                                        a.label++, i = t[1], t = [0];
                                        continue;
                                    case 7:
                                        t = a.ops.pop(), a.trys.pop();
                                        continue;
                                    default:
                                        if (!(s = 0 < (s = a.trys).length && s[s.length - 1]) && (6 === t[0] || 2 === t[0])) { a = 0; continue }
                                        if (3 === t[0] && (!s || t[1] > s[0] && t[1] < s[3])) { a.label = t[1]; break }
                                        if (6 === t[0] && a.label < s[1]) { a.label = s[1], s = t; break }
                                        if (s && a.label < s[2]) { a.label = s[2], a.ops.push(t); break }
                                        s[2] && a.ops.pop(), a.trys.pop();
                                        continue
                                }
                                t = n.call(r, a)
                            } catch (e) { t = [6, e], i = 0 } finally { o = s = 0 }
                            if (5 & t[0]) throw t[1];
                            return { value: t[0] ? t[1] : void 0, done: !0 }
                        }([t, e])
                    }
                }
            }

            function v() {
                for (var e = 0, t = 0, r = arguments.length; t < r; t++) e += arguments[t].length;
                for (var n = Array(e), o = 0, t = 0; t < r; t++)
                    for (var i = arguments[t], s = 0, a = i.length; s < a; s++, o++) n[o] = i[s];
                return n
            }
            var o, s = "FirebaseError",
                u = (t(c, o = Error), c);

            function c(e, t, r) { t = o.call(this, t) || this; return t.code = e, t.customData = r, t.name = s, Object.setPrototypeOf(t, c.prototype), Error.captureStackTrace && Error.captureStackTrace(t, l.prototype.create), t }
            var l = (h.prototype.create = function(e) {
                for (var t = [], r = 1; r < arguments.length; r++) t[r - 1] = arguments[r];
                var n, o = t[0] || {},
                    i = this.service + "/" + e,
                    e = this.errors[e],
                    e = e ? (n = o, e.replace(p, function(e, t) { var r = n[t]; return null != r ? String(r) : "<" + t + "?>" })) : "Error",
                    e = this.serviceName + ": " + e + " (" + i + ").";
                return new u(i, e, o)
            }, h);

            function h(e, t, r) { this.service = e, this.serviceName = t, this.errors = r }
            var p = /\{\$([^}]+)}/g,
                f = (d.prototype.setInstantiationMode = function(e) { return this.instantiationMode = e, this }, d.prototype.setMultipleInstances = function(e) { return this.multipleInstances = e, this }, d.prototype.setServiceProps = function(e) { return this.serviceProps = e, this }, d);

            function d(e, t, r) { this.name = e, this.instanceFactory = t, this.type = r, this.multipleInstances = !1, this.serviceProps = {}, this.instantiationMode = "LAZY" }
            var _, m = "firebasestorage.googleapis.com",
                b = 12e4,
                g = 6e5,
                y = (t(R, _ = u), R.prototype.codeEquals = function(e) { return T(e) === this.code }, Object.defineProperty(R.prototype, "message", { get: function() { return this.customData.serverResponse ? this.message + "\n" + this.customData.serverResponse : this.message }, enumerable: !1, configurable: !0 }), Object.defineProperty(R.prototype, "serverResponse", { get: function() { return this.customData.serverResponse }, set: function(e) { this.customData.serverResponse = e }, enumerable: !1, configurable: !0 }), R);

            function R(e, t) { t = _.call(this, T(e), "Firebase Storage: " + t) || this; return t.customData = { serverResponse: null }, Object.setPrototypeOf(t, R.prototype), t }
            var w = { UNKNOWN: "unknown", OBJECT_NOT_FOUND: "object-not-found", BUCKET_NOT_FOUND: "bucket-not-found", PROJECT_NOT_FOUND: "project-not-found", QUOTA_EXCEEDED: "quota-exceeded", UNAUTHENTICATED: "unauthenticated", UNAUTHORIZED: "unauthorized", RETRY_LIMIT_EXCEEDED: "retry-limit-exceeded", INVALID_CHECKSUM: "invalid-checksum", CANCELED: "canceled", INVALID_EVENT_NAME: "invalid-event-name", INVALID_URL: "invalid-url", INVALID_DEFAULT_BUCKET: "invalid-default-bucket", NO_DEFAULT_BUCKET: "no-default-bucket", CANNOT_SLICE_BLOB: "cannot-slice-blob", SERVER_FILE_WRONG_SIZE: "server-file-wrong-size", NO_DOWNLOAD_URL: "no-download-url", INVALID_ARGUMENT: "invalid-argument", INVALID_ARGUMENT_COUNT: "invalid-argument-count", APP_DELETED: "app-deleted", INVALID_ROOT_OPERATION: "invalid-root-operation", INVALID_FORMAT: "invalid-format", INTERNAL_ERROR: "internal-error" };

            function T(e) { return "storage/" + e }

            function E() { return new y(w.UNKNOWN, "An unknown error occurred, please check the error payload for server response.") }

            function O() { return new y(w.CANCELED, "User canceled the upload/download.") }

            function k() { return new y(w.CANNOT_SLICE_BLOB, "Cannot slice blob for upload. Please retry the upload.") }

            function U() { return new y(w.APP_DELETED, "The Firebase app was deleted.") }

            function A(e, t) { return new y(w.INVALID_FORMAT, "String does not match format '" + e + "': " + t) }

            function N(e) { throw new y(w.INTERNAL_ERROR, "Internal error: " + e) }
            var I = { RAW: "raw", BASE64: "base64", BASE64URL: "base64url", DATA_URL: "data_url" },
                x = function(e, t) { this.data = e, this.contentType = t || null };

            function C(e, t) {
                switch (e) {
                    case I.RAW:
                        return new x(S(t));
                    case I.BASE64:
                    case I.BASE64URL:
                        return new x(P(e, t));
                    case I.DATA_URL:
                        return new x(function(e) { e = new L(e); return e.base64 ? P(I.BASE64, e.rest) : function(e) { var t; try { t = decodeURIComponent(e) } catch (e) { throw A(I.DATA_URL, "Malformed data URL.") } return S(t) }(e.rest) }(t), new L(t).contentType)
                }
                throw E()
            }

            function S(e) {
                for (var t = [], r = 0; r < e.length; r++) {
                    var n = e.charCodeAt(r);
                    n <= 127 ? t.push(n) : n <= 2047 ? t.push(192 | n >> 6, 128 | 63 & n) : 55296 == (64512 & n) ? r < e.length - 1 && 56320 == (64512 & e.charCodeAt(r + 1)) ? (n = 65536 | (1023 & n) << 10 | 1023 & e.charCodeAt(++r), t.push(240 | n >> 18, 128 | n >> 12 & 63, 128 | n >> 6 & 63, 128 | 63 & n)) : t.push(239, 191, 189) : 56320 == (64512 & n) ? t.push(239, 191, 189) : t.push(224 | n >> 12, 128 | n >> 6 & 63, 128 | 63 & n)
                }
                return new Uint8Array(t)
            }

            function P(t, e) {
                switch (t) {
                    case I.BASE64:
                        var r = -1 !== e.indexOf("-"),
                            n = -1 !== e.indexOf("_");
                        if (r || n) throw A(t, "Invalid character '" + (r ? "-" : "_") + "' found: is it base64url encoded?");
                        break;
                    case I.BASE64URL:
                        n = -1 !== e.indexOf("+"), r = -1 !== e.indexOf("/");
                        if (n || r) throw A(t, "Invalid character '" + (n ? "+" : "/") + "' found: is it base64 encoded?");
                        e = e.replace(/-/g, "+").replace(/_/g, "/")
                }
                var o;
                try { o = atob(e) } catch (e) { throw A(t, "Invalid character found") }
                for (var i = new Uint8Array(o.length), s = 0; s < o.length; s++) i[s] = o.charCodeAt(s);
                return i
            }
            var L = function(e) {
                var t;
                if (this.base64 = !1, (this.contentType = null) === (t = e.match(/^data:([^,]+)?,/))) throw A(I.DATA_URL, "Must be formatted 'data:[<mediatype>][;base64],<data>");
                var r, n = t[1] || null;
                null != n && (this.base64 = (r = ";base64", (t = n).length >= r.length && t.substring(t.length - r.length) === r), this.contentType = this.base64 ? n.substring(0, n.length - ";base64".length) : n), this.rest = e.substring(e.indexOf(",") + 1)
            };
            var D, M, B = { STATE_CHANGED: "state_changed" },
                j = "running",
                q = "pausing",
                F = "paused",
                H = "success",
                z = "canceling",
                G = "canceled",
                V = "error",
                X = { RUNNING: "running", PAUSED: "paused", SUCCESS: "success", CANCELED: "canceled", ERROR: "error" };

            function W(e) {
                switch (e) {
                    case j:
                    case q:
                    case z:
                        return X.RUNNING;
                    case F:
                        return X.PAUSED;
                    case H:
                        return X.SUCCESS;
                    case G:
                        return X.CANCELED;
                    case V:
                    default:
                        return X.ERROR
                }
            }

            function K(e) { return null != e }

            function Z(e) { return "string" == typeof e || e instanceof String }

            function J(e) { return Y() && e instanceof Blob }

            function Y() { return "undefined" != typeof Blob }

            function $(e, t, r, n) { if (n < t) throw new y(w.INVALID_ARGUMENT, "Invalid value for '" + e + "'. Expected " + t + " or greater."); if (r < n) throw new y(w.INVALID_ARGUMENT, "Invalid value for '" + e + "'. Expected " + r + " or less.") }(M = D = D || {})[M.NO_ERROR = 0] = "NO_ERROR", M[M.NETWORK_ERROR = 1] = "NETWORK_ERROR", M[M.ABORT = 2] = "ABORT";
            var Q = (ee.prototype.send = function(e, t, r, n) {
                if (this.sent_) throw N("cannot .send() more than once");
                if (this.sent_ = !0, this.xhr_.open(t, e, !0), K(n))
                    for (var o in n) n.hasOwnProperty(o) && this.xhr_.setRequestHeader(o, n[o].toString());
                return K(r) ? this.xhr_.send(r) : this.xhr_.send(), this.sendPromise_
            }, ee.prototype.getErrorCode = function() { if (!this.sent_) throw N("cannot .getErrorCode() before sending"); return this.errorCode_ }, ee.prototype.getStatus = function() { if (!this.sent_) throw N("cannot .getStatus() before sending"); try { return this.xhr_.status } catch (e) { return -1 } }, ee.prototype.getResponseText = function() { if (!this.sent_) throw N("cannot .getResponseText() before sending"); return this.xhr_.responseText }, ee.prototype.abort = function() { this.xhr_.abort() }, ee.prototype.getResponseHeader = function(e) { return this.xhr_.getResponseHeader(e) }, ee.prototype.addUploadProgressListener = function(e) { K(this.xhr_.upload) && this.xhr_.upload.addEventListener("progress", e) }, ee.prototype.removeUploadProgressListener = function(e) { K(this.xhr_.upload) && this.xhr_.upload.removeEventListener("progress", e) }, ee);

            function ee() {
                var t = this;
                this.sent_ = !1, this.xhr_ = new XMLHttpRequest, this.errorCode_ = D.NO_ERROR, this.sendPromise_ = new Promise(function(e) { t.xhr_.addEventListener("abort", function() { t.errorCode_ = D.ABORT, e(t) }), t.xhr_.addEventListener("error", function() { t.errorCode_ = D.NETWORK_ERROR, e(t) }), t.xhr_.addEventListener("load", function() { e(t) }) })
            }
            var te = (re.prototype.createXhrIo = function() { return new Q }, re);

            function re() {}

            function ne() { for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t]; var r = "undefined" != typeof BlobBuilder ? BlobBuilder : "undefined" != typeof WebKitBlobBuilder ? WebKitBlobBuilder : void 0; if (void 0 !== r) { for (var n = new r, o = 0; o < e.length; o++) n.append(e[o]); return n.getBlob() } if (Y()) return new Blob(e); throw Error("This browser doesn't seem to support creating Blobs") }
            var oe = (ie.prototype.size = function() { return this.size_ }, ie.prototype.type = function() { return this.type_ }, ie.prototype.slice = function(e, t) {
                if (J(this.data_)) {
                    var r = this.data_,
                        n = (o = e, n = t, (r = r).webkitSlice ? r.webkitSlice(o, n) : r.mozSlice ? r.mozSlice(o, n) : r.slice ? r.slice(o, n) : null);
                    return null === n ? null : new ie(n)
                }
                var o, n;
                return new ie(new Uint8Array(this.data_.buffer, e, t - e), !0)
            }, ie.getBlob = function() {
                for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                if (Y()) { var r = e.map(function(e) { return e instanceof ie ? e.data_ : e }); return new ie(ne.apply(null, r)) }
                var r = e.map(function(e) { return Z(e) ? C(I.RAW, e).data : e.data_ }),
                    n = 0;
                r.forEach(function(e) { n += e.byteLength });
                var o = new Uint8Array(n),
                    i = 0;
                return r.forEach(function(e) { for (var t = 0; t < e.length; t++) o[i++] = e[t] }), new ie(o, !0)
            }, ie.prototype.uploadData = function() { return this.data_ }, ie);

            function ie(e, t) {
                var r = 0,
                    n = "";
                J(e) ? (r = (this.data_ = e).size, n = e.type) : e instanceof ArrayBuffer ? (t ? this.data_ = new Uint8Array(e) : (this.data_ = new Uint8Array(e.byteLength), this.data_.set(new Uint8Array(e))), r = this.data_.length) : e instanceof Uint8Array && (t ? this.data_ = e : (this.data_ = new Uint8Array(e.length), this.data_.set(e)), r = e.length), this.size_ = r, this.type_ = n
            }
            var se = (Object.defineProperty(ae.prototype, "path", { get: function() { return this.path_ }, enumerable: !1, configurable: !0 }), Object.defineProperty(ae.prototype, "isRoot", { get: function() { return 0 === this.path.length }, enumerable: !1, configurable: !0 }), ae.prototype.fullServerUrl = function() { var e = encodeURIComponent; return "/b/" + e(this.bucket) + "/o/" + e(this.path) }, ae.prototype.bucketOnlyServerUrl = function() { return "/b/" + encodeURIComponent(this.bucket) + "/o" }, ae.makeFromBucketSpec = function(t) { var e, r; try { e = ae.makeFromUrl(t) } catch (e) { return new ae(t, "") } if ("" === e.path) return e; throw r = t, new y(w.INVALID_DEFAULT_BUCKET, "Invalid default bucket '" + r + "'.") }, ae.makeFromUrl = function(e) {
                var t = null,
                    r = "([A-Za-z0-9.\\-_]+)";
                var n = new RegExp("^gs://" + r + "(/(.*))?$", "i");

                function o(e) { e.path_ = decodeURIComponent(e.path) }
                for (var i = m.replace(/[.]/g, "\\."), s = [{ regex: n, indices: { bucket: 1, path: 3 }, postModify: function(e) { "/" === e.path.charAt(e.path.length - 1) && (e.path_ = e.path_.slice(0, -1)) } }, { regex: new RegExp("^https?://" + i + "/v[A-Za-z0-9_]+/b/" + r + "/o(/([^?#]*).*)?$", "i"), indices: { bucket: 1, path: 3 }, postModify: o }, { regex: new RegExp("^https?://(?:storage.googleapis.com|storage.cloud.google.com)/" + r + "/([^?#]*)", "i"), indices: { bucket: 1, path: 2 }, postModify: o }], a = 0; a < s.length; a++) {
                    var u = s[a],
                        c = u.regex.exec(e);
                    if (c) {
                        t = new ae(c[u.indices.bucket], c[u.indices.path] || "");
                        u.postModify(t);
                        break
                    }
                }
                if (null == t) throw r = e, new y(w.INVALID_URL, "Invalid URL '" + r + "'.");
                return t
            }, ae);

            function ae(e, t) { this.bucket = e, this.path_ = t }

            function ue(e) { var t, r; try { t = JSON.parse(e) } catch (e) { return null } return "object" != typeof(r = t) || Array.isArray(r) ? null : t }

            function ce(e) { var t = e.lastIndexOf("/", e.length - 2); return -1 === t ? e : e.slice(t + 1) }

            function le(e) { return "https://" + m + "/v0" + e }

            function he(e) {
                var t, r = encodeURIComponent,
                    n = "?";
                for (t in e) { e.hasOwnProperty(t) && (n = n + (r(t) + "=" + r(e[t])) + "&") }
                return n = n.slice(0, -1)
            }

            function pe(e, t) { return t }
            var fe = function(e, t, r, n) { this.server = e, this.local = t || e, this.writable = !!r, this.xform = n || pe },
                de = null;

            function _e() {
                if (de) return de;
                var e = [];
                e.push(new fe("bucket")), e.push(new fe("generation")), e.push(new fe("metageneration")), e.push(new fe("name", "fullPath", !0));
                var t = new fe("name");
                t.xform = function(e, t) { return !Z(t = t) || t.length < 2 ? t : ce(t) }, e.push(t);
                t = new fe("size");
                return t.xform = function(e, t) { return K(t) ? Number(t) : t }, e.push(t), e.push(new fe("timeCreated")), e.push(new fe("updated")), e.push(new fe("md5Hash", null, !0)), e.push(new fe("cacheControl", null, !0)), e.push(new fe("contentDisposition", null, !0)), e.push(new fe("contentEncoding", null, !0)), e.push(new fe("contentLanguage", null, !0)), e.push(new fe("contentType", null, !0)), e.push(new fe("metadata", "customMetadata", !0)), de = e
            }

            function ve(r, n) {
                Object.defineProperty(r, "ref", {
                    get: function() {
                        var e = r.bucket,
                            t = r.fullPath,
                            t = new se(e, t);
                        return n.makeStorageReference(t)
                    }
                })
            }

            function me(e, t, r) {
                t = ue(t);
                if (null === t) return null;
                return function(e, t, r) {
                    for (var n = { type: "file" }, o = r.length, i = 0; i < o; i++) {
                        var s = r[i];
                        n[s.local] = s.xform(n, t[s.server])
                    }
                    return ve(n, e), n
                }(e, t, r)
            }

            function be(e, t) {
                for (var r = {}, n = t.length, o = 0; o < n; o++) {
                    var i = t[o];
                    i.writable && (r[i.server] = e[i.local])
                }
                return JSON.stringify(r)
            }
            var ge = "prefixes",
                ye = "items";

            function Re(e, t, r) {
                r = ue(r);
                if (null === r) return null;
                return function(e, t, r) {
                    var n = { prefixes: [], items: [], nextPageToken: r.nextPageToken };
                    if (r[ge])
                        for (var o = 0, i = r[ge]; o < i.length; o++) {
                            var s = i[o].replace(/\/$/, ""),
                                a = e.makeStorageReference(new se(t, s));
                            n.prefixes.push(a)
                        }
                    if (r[ye])
                        for (var u = 0, c = r[ye]; u < c.length; u++) {
                            var l = c[u],
                                a = e.makeStorageReference(new se(t, l.name));
                            n.items.push(a)
                        }
                    return n
                }(e, t, r)
            }
            var we = function(e, t, r, n) { this.url = e, this.method = t, this.handler = r, this.timeout = n, this.urlParams = {}, this.headers = {}, this.body = null, this.errorHandler = null, this.progressCallback = null, this.successCodes = [200], this.additionalRetryCodes = [] };

            function Te(e) { if (!e) throw E() }

            function Ee(r, n) { return function(e, t) { return Te(null !== (t = me(r, t, n))), t } }

            function Oe(r, n) { return function(e, t) { return Te(null !== (t = Re(r, n, t))), t } }

            function ke(n, o) {
                return function(e, t) {
                    var r = me(n, t, o);
                    return Te(null !== r),
                        function(n, e) {
                            if (null === (e = ue(e))) return null;
                            if (!Z(e.downloadTokens)) return null;
                            if (0 === (e = e.downloadTokens).length) return null;
                            var o = encodeURIComponent;
                            return e.split(",").map(function(e) {
                                var t = n.bucket,
                                    r = n.fullPath;
                                return le("/b/" + o(t) + "/o/" + o(r)) + he({ alt: "media", token: e })
                            })[0]
                        }(r, t)
                }
            }

            function Ue(o) { return function(e, t) { var r, n = 401 === e.getStatus() ? new y(w.UNAUTHENTICATED, "User is not authenticated, please authenticate using Firebase Authentication and try again.") : 402 === e.getStatus() ? (r = o.bucket, new y(w.QUOTA_EXCEEDED, "Quota for bucket '" + r + "' exceeded, please view quota on https://firebase.google.com/pricing/.")) : 403 === e.getStatus() ? (n = o.path, new y(w.UNAUTHORIZED, "User does not have permission to access '" + n + "'.")) : t; return n.serverResponse = t.serverResponse, n } }

            function Ae(n) { var o = Ue(n); return function(e, t) { var r = o(e, t); return 404 === e.getStatus() && (e = n.path, r = new y(w.OBJECT_NOT_FOUND, "Object '" + e + "' does not exist.")), r.serverResponse = t.serverResponse, r } }

            function Ne(e, t, r) {
                var n = le(t.fullServerUrl()),
                    o = e.maxOperationRetryTime,
                    o = new we(n, "GET", Ee(e, r), o);
                return o.errorHandler = Ae(t), o
            }

            function Ie(e, t, r) { r = Object.assign({}, r); return r.fullPath = e.path, r.size = t.size(), r.contentType || (r.contentType = (e = t, (t = null) && t.contentType || e && e.type() || "application/octet-stream")), r }

            function xe(e, t, r, n, o) {
                var i = t.bucketOnlyServerUrl(),
                    s = { "X-Goog-Upload-Protocol": "multipart" };
                var a = function() { for (var e = "", t = 0; t < 2; t++) e += Math.random().toString().slice(2); return e }();
                s["Content-Type"] = "multipart/related; boundary=" + a;
                var u = Ie(t, n, o),
                    o = "--" + a + "\r\nContent-Type: application/json; charset=utf-8\r\n\r\n" + be(u, r) + "\r\n--" + a + "\r\nContent-Type: " + u.contentType + "\r\n\r\n",
                    a = "\r\n--" + a + "--",
                    n = oe.getBlob(o, n, a);
                if (null === n) throw k();
                a = { name: u.fullPath }, u = le(i), i = e.maxUploadRetryTime, i = new we(u, "POST", Ee(e, r), i);
                return i.urlParams = a, i.headers = s, i.body = n.uploadData(), i.errorHandler = Ue(t), i
            }
            var Ce = function(e, t, r, n) { this.current = e, this.total = t, this.finalized = !!r, this.metadata = n || null };

            function Se(e, t) { var r = null; try { r = e.getResponseHeader("X-Goog-Upload-Status") } catch (e) { Te(!1) } return Te(!!r && -1 !== (t || ["active"]).indexOf(r)), r }

            function Pe(e, t, r, n, o) {
                var i = t.bucketOnlyServerUrl(),
                    s = Ie(t, n, o),
                    o = { name: s.fullPath },
                    i = le(i),
                    n = { "X-Goog-Upload-Protocol": "resumable", "X-Goog-Upload-Command": "start", "X-Goog-Upload-Header-Content-Length": n.size(), "X-Goog-Upload-Header-Content-Type": s.contentType, "Content-Type": "application/json; charset=utf-8" },
                    r = be(s, r),
                    e = e.maxUploadRetryTime;
                e = new we(i, "POST", function(e) {
                    var t;
                    Se(e);
                    try { t = e.getResponseHeader("X-Goog-Upload-URL") } catch (e) { Te(!1) }
                    return Te(Z(t)), t
                }, e);
                return e.urlParams = o, e.headers = n, e.body = r, e.errorHandler = Ue(t), e
            }

            function Le(e, t, r, o) {
                e = e.maxUploadRetryTime, e = new we(r, "POST", function(e) {
                    var t = Se(e, ["active", "final"]),
                        r = null;
                    try { r = e.getResponseHeader("X-Goog-Upload-Size-Received") } catch (e) { Te(!1) }
                    r || Te(!1);
                    var n = Number(r);
                    return Te(!isNaN(n)), new Ce(n, o.size(), "final" === t)
                }, e);
                return e.headers = { "X-Goog-Upload-Command": "query" }, e.errorHandler = Ue(t), e
            }

            function De(e, i, t, s, r, a, n, o) {
                var u = new Ce(0, 0);
                if (n ? (u.current = n.current, u.total = n.total) : (u.current = 0, u.total = s.size()), s.size() !== u.total) throw new y(w.SERVER_FILE_WRONG_SIZE, "Server recorded incorrect upload file size, please retry the upload.");
                var c = u.total - u.current,
                    l = c;
                0 < r && (l = Math.min(l, r));
                n = u.current, r = n + l, c = { "X-Goog-Upload-Command": l === c ? "upload, finalize" : "upload", "X-Goog-Upload-Offset": u.current }, n = s.slice(n, r);
                if (null === n) throw k();
                r = i.maxUploadRetryTime, r = new we(t, "POST", function(e, t) {
                    var r = Se(e, ["active", "final"]),
                        n = u.current + l,
                        o = s.size(),
                        t = "final" === r ? Ee(i, a)(e, t) : null;
                    return new Ce(n, o, "final" === r, t)
                }, r);
                return r.headers = c, r.body = n.uploadData(), r.progressCallback = o || null, r.errorHandler = Ue(e), r
            }
            var Me = function(e, t, r) { "function" == typeof e || K(t) || K(r) ? (this.next = e, this.error = t || null, this.complete = r || null) : (e = e, this.next = e.next || null, this.error = e.error || null, this.complete = e.complete || null) },
                Be = function(e, t, r, n, o, i) { this.bytesTransferred = e, this.totalBytes = t, this.state = r, this.metadata = n, this.task = o, this.ref = i };

            function je(r) {
                return function() {
                    for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                    Promise.resolve().then(function() { return r.apply(void 0, e) })
                }
            }
            var qe = (Fe.prototype.makeProgressCallback_ = function() {
                var t = this,
                    r = this.transferred_;
                return function(e) { return t.updateProgress_(r + e) }
            }, Fe.prototype.shouldDoResumable_ = function(e) { return 262144 < e.size() }, Fe.prototype.start_ = function() { this.state_ === j && null === this.request_ && (this.resumable_ ? null === this.uploadUrl_ ? this.createResumable_() : this.needToFetchStatus_ ? this.fetchStatus_() : this.needToFetchMetadata_ ? this.fetchMetadata_() : this.continueUpload_() : this.oneShotUpload_()) }, Fe.prototype.resolveToken_ = function(t) {
                var r = this;
                this.service_.getAuthToken().then(function(e) {
                    switch (r.state_) {
                        case j:
                            t(e);
                            break;
                        case z:
                            r.transition_(G);
                            break;
                        case q:
                            r.transition_(F)
                    }
                })
            }, Fe.prototype.createResumable_ = function() {
                var r = this;
                this.resolveToken_(function(e) {
                    var t = Pe(r.service_, r.location_, r.mappings_, r.blob_, r.metadata_),
                        e = r.service_.makeRequest(t, e);
                    (r.request_ = e).getPromise().then(function(e) { r.request_ = null, r.uploadUrl_ = e, r.needToFetchStatus_ = !1, r.completeTransitions_() }, r.errorHandler_)
                })
            }, Fe.prototype.fetchStatus_ = function() {
                var r = this,
                    n = this.uploadUrl_;
                this.resolveToken_(function(e) {
                    var t = Le(r.service_, r.location_, n, r.blob_),
                        e = r.service_.makeRequest(t, e);
                    (r.request_ = e).getPromise().then(function(e) { r.request_ = null, r.updateProgress_(e.current), r.needToFetchStatus_ = !1, e.finalized && (r.needToFetchMetadata_ = !0), r.completeTransitions_() }, r.errorHandler_)
                })
            }, Fe.prototype.continueUpload_ = function() {
                var r = this,
                    n = 262144 * this.chunkMultiplier_,
                    o = new Ce(this.transferred_, this.blob_.size()),
                    i = this.uploadUrl_;
                this.resolveToken_(function(e) {
                    var t;
                    try { t = De(r.location_, r.service_, i, r.blob_, n, r.mappings_, o, r.makeProgressCallback_()) } catch (e) { return r.error_ = e, void r.transition_(V) }
                    e = r.service_.makeRequest(t, e);
                    (r.request_ = e).getPromise().then(function(e) { r.increaseMultiplier_(), r.request_ = null, r.updateProgress_(e.current), e.finalized ? (r.metadata_ = e.metadata, r.transition_(H)) : r.completeTransitions_() }, r.errorHandler_)
                })
            }, Fe.prototype.increaseMultiplier_ = function() { 262144 * this.chunkMultiplier_ < 33554432 && (this.chunkMultiplier_ *= 2) }, Fe.prototype.fetchMetadata_ = function() {
                var r = this;
                this.resolveToken_(function(e) {
                    var t = Ne(r.service_, r.location_, r.mappings_),
                        e = r.service_.makeRequest(t, e);
                    (r.request_ = e).getPromise().then(function(e) { r.request_ = null, r.metadata_ = e, r.transition_(H) }, r.metadataErrorHandler_)
                })
            }, Fe.prototype.oneShotUpload_ = function() {
                var r = this;
                this.resolveToken_(function(e) {
                    var t = xe(r.service_, r.location_, r.mappings_, r.blob_, r.metadata_),
                        e = r.service_.makeRequest(t, e);
                    (r.request_ = e).getPromise().then(function(e) { r.request_ = null, r.metadata_ = e, r.updateProgress_(r.blob_.size()), r.transition_(H) }, r.errorHandler_)
                })
            }, Fe.prototype.updateProgress_ = function(e) {
                var t = this.transferred_;
                this.transferred_ = e, this.transferred_ !== t && this.notifyObservers_()
            }, Fe.prototype.transition_ = function(e) {
                if (this.state_ !== e) switch (e) {
                    case z:
                    case q:
                        this.state_ = e, null !== this.request_ && this.request_.cancel();
                        break;
                    case j:
                        var t = this.state_ === F;
                        this.state_ = e, t && (this.notifyObservers_(), this.start_());
                        break;
                    case F:
                        this.state_ = e, this.notifyObservers_();
                        break;
                    case G:
                        this.error_ = O(), this.state_ = e, this.notifyObservers_();
                        break;
                    case V:
                    case H:
                        this.state_ = e, this.notifyObservers_()
                }
            }, Fe.prototype.completeTransitions_ = function() {
                switch (this.state_) {
                    case q:
                        this.transition_(F);
                        break;
                    case z:
                        this.transition_(G);
                        break;
                    case j:
                        this.start_()
                }
            }, Object.defineProperty(Fe.prototype, "snapshot", { get: function() { var e = W(this.state_); return new Be(this.transferred_, this.blob_.size(), e, this.metadata_, this, this.ref_) }, enumerable: !1, configurable: !0 }), Fe.prototype.on = function(e, t, r, n) {
                var o = this,
                    i = new Me(t, r, n);
                return this.addObserver_(i),
                    function() { o.removeObserver_(i) }
            }, Fe.prototype.then = function(e, t) { return this.promise_.then(e, t) }, Fe.prototype.catch = function(e) { return this.then(null, e) }, Fe.prototype.addObserver_ = function(e) { this.observers_.push(e), this.notifyObserver_(e) }, Fe.prototype.removeObserver_ = function(e) { e = this.observers_.indexOf(e); - 1 !== e && this.observers_.splice(e, 1) }, Fe.prototype.notifyObservers_ = function() {
                var t = this;
                this.finishPromise_(), this.observers_.slice().forEach(function(e) { t.notifyObserver_(e) })
            }, Fe.prototype.finishPromise_ = function() {
                if (null !== this.resolve_) {
                    var e = !0;
                    switch (W(this.state_)) {
                        case X.SUCCESS:
                            je(this.resolve_.bind(null, this.snapshot))();
                            break;
                        case X.CANCELED:
                        case X.ERROR:
                            je(this.reject_.bind(null, this.error_))();
                            break;
                        default:
                            e = !1
                    }
                    e && (this.resolve_ = null, this.reject_ = null)
                }
            }, Fe.prototype.notifyObserver_ = function(e) {
                switch (W(this.state_)) {
                    case X.RUNNING:
                    case X.PAUSED:
                        e.next && je(e.next.bind(e, this.snapshot))();
                        break;
                    case X.SUCCESS:
                        e.complete && je(e.complete.bind(e))();
                        break;
                    case X.CANCELED:
                    case X.ERROR:
                        e.error && je(e.error.bind(e, this.error_))();
                        break;
                    default:
                        e.error && je(e.error.bind(e, this.error_))()
                }
            }, Fe.prototype.resume = function() { var e = this.state_ === F || this.state_ === q; return e && this.transition_(j), e }, Fe.prototype.pause = function() { var e = this.state_ === j; return e && this.transition_(q), e }, Fe.prototype.cancel = function() { var e = this.state_ === j || this.state_ === q; return e && this.transition_(z), e }, Fe);

            function Fe(e, t, r, n, o, i) {
                var s = this;
                void 0 === i && (i = null), this.transferred_ = 0, this.needToFetchStatus_ = !1, this.needToFetchMetadata_ = !1, this.observers_ = [], this.error_ = null, this.uploadUrl_ = null, this.request_ = null, this.chunkMultiplier_ = 1, this.resolve_ = null, this.reject_ = null, this.ref_ = e, this.service_ = t, this.location_ = r, this.blob_ = o, this.metadata_ = i, this.mappings_ = n, this.resumable_ = this.shouldDoResumable_(this.blob_), this.state_ = j, this.errorHandler_ = function(e) { s.request_ = null, s.chunkMultiplier_ = 1, e.codeEquals(w.CANCELED) ? (s.needToFetchStatus_ = !0, s.completeTransitions_()) : (s.error_ = e, s.transition_(V)) }, this.metadataErrorHandler_ = function(e) { s.request_ = null, e.codeEquals(w.CANCELED) ? s.completeTransitions_() : (s.error_ = e, s.transition_(V)) }, this.promise_ = new Promise(function(e, t) { s.resolve_ = e, s.reject_ = t, s.start_() }), this.promise_.then(null, function() {})
            }
            var He = (ze.prototype.toString = function() { return "gs://" + this.location.bucket + "/" + this.location.path }, ze.prototype.newRef = function(e, t) { return new ze(e, t) }, ze.prototype.mappings = _e, ze.prototype.child = function(e) {
                var t, e = (t = this.location.path, e = (e = e).split("/").filter(function(e) { return 0 < e.length }).join("/"), 0 === t.length ? e : t + "/" + e),
                    e = new se(this.location.bucket, e);
                return this.newRef(this.service, e)
            }, Object.defineProperty(ze.prototype, "parent", {
                get: function() {
                    var e = function(e) { if (0 === e.length) return null; var t = e.lastIndexOf("/"); return -1 === t ? "" : e.slice(0, t) }(this.location.path);
                    if (null === e) return null;
                    e = new se(this.location.bucket, e);
                    return this.newRef(this.service, e)
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(ze.prototype, "root", { get: function() { var e = new se(this.location.bucket, ""); return this.newRef(this.service, e) }, enumerable: !1, configurable: !0 }), Object.defineProperty(ze.prototype, "bucket", { get: function() { return this.location.bucket }, enumerable: !1, configurable: !0 }), Object.defineProperty(ze.prototype, "fullPath", { get: function() { return this.location.path }, enumerable: !1, configurable: !0 }), Object.defineProperty(ze.prototype, "name", { get: function() { return ce(this.location.path) }, enumerable: !1, configurable: !0 }), Object.defineProperty(ze.prototype, "storage", { get: function() { return this.service }, enumerable: !1, configurable: !0 }), ze.prototype.put = function(e, t) { return void 0 === t && (t = null), this.throwIfRoot_("put"), new qe(this, this.service, this.location, this.mappings(), new oe(e), t) }, ze.prototype.putString = function(e, t, r) {
                void 0 === t && (t = I.RAW), this.throwIfRoot_("putString");
                e = C(t, e), r = Object.assign({}, r);
                return !K(r.contentType) && K(e.contentType) && (r.contentType = e.contentType), new qe(this, this.service, this.location, this.mappings(), new oe(e.data, !0), r)
            }, ze.prototype.delete = function() { var o = this; return this.throwIfRoot_("delete"), this.service.getAuthToken().then(function(e) { var t, r, n, t = (t = o.service, r = o.location, n = le(r.fullServerUrl()), t = t.maxOperationRetryTime, (t = new we(n, "DELETE", function(e, t) {}, t)).successCodes = [200, 204], t.errorHandler = Ae(r), t); return o.service.makeRequest(t, e).getPromise() }) }, ze.prototype.listAll = function() { var e = { prefixes: [], items: [] }; return this.listAllHelper(e).then(function() { return e }) }, ze.prototype.listAllHelper = function(n, o) {
                return r(this, void 0, void 0, function() {
                    var t, r;
                    return i(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return r = { pageToken: o }, [4, this.list(r)];
                            case 1:
                                return t = e.sent(), (r = n.prefixes).push.apply(r, t.prefixes), (r = n.items).push.apply(r, t.items), null == t.nextPageToken ? [3, 3] : [4, this.listAllHelper(n, t.nextPageToken)];
                            case 2:
                                e.sent(), e.label = 3;
                            case 3:
                                return [2]
                        }
                    })
                })
            }, ze.prototype.list = function(e) {
                var a = this,
                    u = e || {};
                return "number" == typeof u.maxResults && $("options.maxResults", 1, 1e3, u.maxResults), this.service.getAuthToken().then(function(e) { var t, r, n, o, i, s, i = (t = a.service, r = a.location, n = "/", o = u.pageToken, i = u.maxResults, s = {}, r.isRoot ? s.prefix = "" : s.prefix = r.path + "/", n && 0 < n.length && (s.delimiter = n), o && (s.pageToken = o), i && (s.maxResults = i), o = le(r.bucketOnlyServerUrl()), i = t.maxOperationRetryTime, (i = new we(o, "GET", Oe(t, r.bucket), i)).urlParams = s, i.errorHandler = Ue(r), i); return a.service.makeRequest(i, e).getPromise() })
            }, ze.prototype.getMetadata = function() { var r = this; return this.throwIfRoot_("getMetadata"), this.service.getAuthToken().then(function(e) { var t = Ne(r.service, r.location, r.mappings()); return r.service.makeRequest(t, e).getPromise() }) }, ze.prototype.updateMetadata = function(a) { var u = this; return this.throwIfRoot_("updateMetadata"), this.service.getAuthToken().then(function(e) { var t, r, n, o, i, s, n = (t = u.service, r = u.location, n = a, o = u.mappings(), i = le(r.fullServerUrl()), s = be(n, o), n = t.maxOperationRetryTime, (n = new we(i, "PATCH", Ee(t, o), n)).headers = { "Content-Type": "application/json; charset=utf-8" }, n.body = s, n.errorHandler = Ae(r), n); return u.service.makeRequest(n, e).getPromise() }) }, ze.prototype.getDownloadURL = function() { var s = this; return this.throwIfRoot_("getDownloadURL"), this.service.getAuthToken().then(function(e) { var t, r, n, o, i, i = (t = s.service, r = s.location, n = s.mappings(), o = le(r.fullServerUrl()), i = t.maxOperationRetryTime, (i = new we(o, "GET", ke(t, n), i)).errorHandler = Ae(r), i); return s.service.makeRequest(i, e).getPromise().then(function(e) { if (null === e) throw new y(w.NO_DOWNLOAD_URL, "The given file does not have any download URLs."); return e }) }) }, ze.prototype.throwIfRoot_ = function(e) { if ("" === this.location.path) throw e = e, new y(w.INVALID_ROOT_OPERATION, "The operation '" + e + "' cannot be performed on a root reference, create a non-root reference using child, such as .child('file.png').") }, ze);

            function ze(e, t) { this.service = e, this.location = t instanceof se ? t : se.makeFromUrl(t) }
            var Ge = (Ve.prototype.getPromise = function() { return this.promise_ }, Ve.prototype.cancel = function(e) {}, Ve);

            function Ve(e) { this.promise_ = Promise.reject(e) }
            var Xe = (We.prototype.start_ = function() {
                var t, r, e, n, o, i, s, a, u, c = this;

                function l(e, t) {
                    var r, n = c.resolve_,
                        o = c.reject_,
                        i = t.xhr;
                    if (t.wasSuccessCode) try {
                        var s = c.callback_(i, i.getResponseText());
                        void 0 !== s ? n(s) : n()
                    } catch (e) { o(e) } else null !== i ? ((r = E()).serverResponse = i.getResponseText(), c.errorCallback_ ? o(c.errorCallback_(i, r)) : o(r)) : t.canceled ? o(r = (c.appDelete_ ? U : O)()) : o(r = new y(w.RETRY_LIMIT_EXCEEDED, "Max retry time for operation exceeded, please try again."))
                }

                function h() { return 2 === s }

                function p() {
                    for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                    a || (a = !0, r.apply(null, e))
                }

                function f(e) { o = setTimeout(function() { o = null, t(d, h()) }, e) }

                function d(e) {
                    for (var t = [], r = 1; r < arguments.length; r++) t[r - 1] = arguments[r];
                    a || (e || h() || i ? p.call.apply(p, v([null, e], t)) : (n < 64 && (n *= 2), f(1 === s ? (s = 2, 0) : 1e3 * (n + Math.random()))))
                }

                function _(e) { u || (u = !0, a || (null !== o ? (e || (s = 2), clearTimeout(o), f(0)) : e || (s = 1))) }
                this.canceled_ ? l(0, new Ke(!1, null, !0)) : this.backoffId_ = (t = function(n, e) {
                    function o(e) {
                        var t = e.loaded,
                            e = e.lengthComputable ? e.total : -1;
                        null !== c.progressCallback_ && c.progressCallback_(t, e)
                    }
                    e ? n(!1, new Ke(!1, null, !0)) : (e = c.pool_.createXhrIo(), c.pendingXhr_ = e, null !== c.progressCallback_ && e.addUploadProgressListener(o), e.send(c.url_, c.method_, c.body_, c.headers_).then(function(e) {
                        null !== c.progressCallback_ && e.removeUploadProgressListener(o), c.pendingXhr_ = null;
                        var t = e.getErrorCode() === D.NO_ERROR,
                            r = e.getStatus();
                        t && !c.isRetryStatusCode_(r) ? (r = -1 !== c.successCodes_.indexOf(r), n(!0, new Ke(r, e))) : (e = e.getErrorCode() === D.ABORT, n(!1, new Ke(!1, null, e)))
                    }))
                }, r = l, e = this.timeout_, o = null, u = a = i = !(n = 1), f(s = 0), setTimeout(function() { _(i = !0) }, e), _)
            }, We.prototype.getPromise = function() { return this.promise_ }, We.prototype.cancel = function(e) { this.canceled_ = !0, this.appDelete_ = e || !1, null !== this.backoffId_ && (0, this.backoffId_)(!1), null !== this.pendingXhr_ && this.pendingXhr_.abort() }, We.prototype.isRetryStatusCode_ = function(e) {
                var t = 500 <= e && e < 600,
                    r = -1 !== [408, 429].indexOf(e),
                    e = -1 !== this.additionalRetryCodes_.indexOf(e);
                return t || r || e
            }, We);

            function We(e, t, r, n, o, i, s, a, u, c, l) {
                var h = this;
                this.pendingXhr_ = null, this.backoffId_ = null, this.canceled_ = !1, this.appDelete_ = !1, this.url_ = e, this.method_ = t, this.headers_ = r, this.body_ = n, this.successCodes_ = o.slice(), this.additionalRetryCodes_ = i.slice(), this.callback_ = s, this.errorCallback_ = a, this.progressCallback_ = c, this.timeout_ = u, this.pool_ = l, this.promise_ = new Promise(function(e, t) { h.resolve_ = e, h.reject_ = t, h.start_() })
            }
            var Ke = function(e, t, r) { this.wasSuccessCode = e, this.xhr = t, this.canceled = !!r };

            function Ze(e, t, r, n) {
                var o = he(e.urlParams),
                    i = e.url + o,
                    s = Object.assign({}, e.headers);
                return o = s, (t = t) && (o["X-Firebase-GMPID"] = t), t = s, null !== (r = r) && 0 < r.length && (t.Authorization = "Firebase " + r), t = s, r = void 0 !== a.default ? a.default.SDK_VERSION : "AppManager", t["X-Firebase-Storage-Version"] = "webjs/" + r, new Xe(i, e.method, s, e.body, e.successCodes, e.additionalRetryCodes, e.handler, e.errorHandler, e.timeout, e.progressCallback, n)
            }
            var Je = (Ye.extractBucket_ = function(e) { e = null == e ? void 0 : e.storageBucket; return null == e ? null : se.makeFromBucketSpec(e) }, Ye.prototype.getAuthToken = function() {
                return r(this, void 0, void 0, function() {
                    var t;
                    return i(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return (t = this.authProvider_.getImmediate({ optional: !0 })) ? [4, t.getToken()] : [3, 2];
                            case 1:
                                if (null !== (t = e.sent())) return [2, t.accessToken];
                                e.label = 2;
                            case 2:
                                return [2, null]
                        }
                    })
                })
            }, Ye.prototype.deleteApp = function() { this.deleted_ = !0, this.app_ = null, this.requests_.forEach(function(e) { return e.cancel() }), this.requests_.clear() }, Ye.prototype.makeStorageReference = function(e) { return new He(this, e) }, Ye.prototype.makeRequest = function(e, t) { var r = this; if (this.deleted_) return new Ge(U()); var n = Ze(e, this.appId_, t, this.pool_); return this.requests_.add(n), n.getPromise().then(function() { return r.requests_.delete(n) }, function() { return r.requests_.delete(n) }), n }, Ye.prototype.ref = function(e) { if (/^[A-Za-z]+:\/\//.test(e)) throw new y(w.INVALID_ARGUMENT, "Expected child path but got a URL, use refFromURL instead."); if (null == this.bucket_) throw new Error("No Storage Bucket defined in Firebase Options."); var t = new He(this, this.bucket_); return null != e ? t.child(e) : t }, Ye.prototype.refFromURL = function(e) { if (!/^[A-Za-z]+:\/\//.test(e)) throw new y(w.INVALID_ARGUMENT, "Expected full URL but got a child path, use ref instead."); try { se.makeFromUrl(e) } catch (e) { throw new y(w.INVALID_ARGUMENT, "Expected valid full URL but got an invalid one.") } return new He(this, e) }, Object.defineProperty(Ye.prototype, "maxUploadRetryTime", { get: function() { return this.maxUploadRetryTime_ }, enumerable: !1, configurable: !0 }), Ye.prototype.setMaxUploadRetryTime = function(e) { $("time", 0, Number.POSITIVE_INFINITY, e), this.maxUploadRetryTime_ = e }, Object.defineProperty(Ye.prototype, "maxOperationRetryTime", { get: function() { return this.maxOperationRetryTime_ }, enumerable: !1, configurable: !0 }), Ye.prototype.setMaxOperationRetryTime = function(e) { $("time", 0, Number.POSITIVE_INFINITY, e), this.maxOperationRetryTime_ = e }, Object.defineProperty(Ye.prototype, "app", { get: function() { return this.app_ }, enumerable: !1, configurable: !0 }), Object.defineProperty(Ye.prototype, "INTERNAL", { get: function() { return this.internals_ }, enumerable: !1, configurable: !0 }), Ye);

            function Ye(e, t, r, n) { this.bucket_ = null, this.appId_ = null, this.deleted_ = !1, this.app_ = e, this.authProvider_ = t, this.maxOperationRetryTime_ = b, this.maxUploadRetryTime_ = g, this.requests_ = new Set, this.pool_ = r, this.bucket_ = null != n ? se.makeFromBucketSpec(n) : Ye.extractBucket_(null === (n = this.app_) || void 0 === n ? void 0 : n.options), this.internals_ = new $e(this) }
            var $e = (Qe.prototype.delete = function() { return this.service_.deleteApp(), Promise.resolve() }, Qe);

            function Qe(e) { this.service_ = e }
            var et, tt;

            function rt(e, t) {
                var r = e.getProvider("app").getImmediate(),
                    e = e.getProvider("auth-internal");
                return new Je(r, e, new te, t)
            }
            et = a.default, tt = { TaskState: X, TaskEvent: B, StringFormat: I, Storage: Je, Reference: He }, et.INTERNAL.registerComponent(new f("storage", rt, "PUBLIC").setServiceProps(tt).setMultipleInstances(!0)), et.registerVersion("@firebase/storage", "0.4.0")
        }).apply(this, arguments)
    } catch (e) { throw console.error(e), new Error("Cannot instantiate firebase-storage.js - be sure to load firebase-app.js first.") }
});
//# sourceMappingURL=firebase-storage.js.map
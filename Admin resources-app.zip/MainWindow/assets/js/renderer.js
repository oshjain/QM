const { ipcRenderer } = require("electron");


var path = require("path");

const AS = new Dexie("General");
AS.version(1).stores({ "DWA": "AD" });
AS.version(1).stores({ "REM": "++id,ED,R,RD" });
AS.version(1).stores({ "CAPCH": "++id,CD,U,B,OV,NV" });

AS.REM.toArray().then(I => {
    if (!I.length) {
        $(".rembadge").addClass("d-none")
    } else {
        showSnackbar("Kindly read your notifications!")
    }
});

function spanText(textStr, textClasses) {
    var classNames = textClasses.map(c => 'text-' + c).join(' ');
    return '<span class="' + classNames + '">' + textStr + '</span>';
}

class RealTimePresence {

    constructor(FB, UL, LD) {
        this.UL = UL; // Users list
        this.FB = FB; // Firebase database
        this.DB = new Dexie(LD); // Local datastore 'General'
        this.DB.version(1).stores({ RTP: "RTPDate" }) // Real time presence store // Keys: Online and Offline time
        this.ST = this.DB.RTP;
        this.TD = getOffsetBetweenTimezonesForDate();
        return this.ROF(), this;
    }

    async getOnce() {
        var self = this;
        var today = this.TD.toLocaleDateString();
        self.RTPD = await self.DB.transaction("rw", self.ST, async() => {
            var RTD = await self.ST.get({ RTPDate: today });
            if (!RTD) {
                RTD = self.getUL(today);
                await self.ST.put(RTD);
            }
            return RTD;
        });
        self.FB.ref('/status').once("value").then(function(snapshot) {
            self.set(new Map(Object.entries(snapshot.val())))
        });

        setTimeout(this.getRT.bind(this), 60000)
    }

    getUL(D) {
        var N = new Date().getTime();
        return {
            RTPDate: D,
            UL: this.UL.map(I => {
                return {
                    User: I.empEmail.split("@")[0].replace(".", "-"),
                    //OnTime: 0,
                    //OffTime: 0,
                    Status: "",
                    //last_changed: N
                }
            })
        }
    }

    getRT() {
        var self = this;
        this.FB.ref('/status').on("value", function(snapshot) {
            self.set(new Map(Object.entries(snapshot.val())))
        });
    }

    ROF() {
        this.On = 0;
        this.Off = 0;
        return this;
    }

    UTM(I, F, T) {

        //var N = F ? F.last_changed : I.last_changed
        I.Status = F ? F.state : "offline"
        if (I.Status == "offline") {
            this.Off += 1;
        } else {
            this.On += 1;
        }
        /*
                if (I.Status == "offline") {
                    I.OffTime = new Date(T - N).getHours();
                } else {
                    I.OnTime = new Date(T - N).getHours();
                }
                I.last_changed = F ? F.last_changed : T;
                */
        return I
    }

    set(UM) {
        var self = this,
            N = new Date().getTime();
        self.ROF();
        var OUT = this.RTPD.UL.map(I => {
            var O = {},
                U = UM.get(I.User)
            return self.UTM(I, U, N)
        }).sort((A, B) => {
            return A.Status > B.Status
        })
        return this.EMap(OUT);
    }

    SBARO(D, C) {


    }

    DCO() {

        var PieChartOptions = {
            chart: {
                width: 380,
                height: 300,
                type: "donut"
            },
            series: [this.On, this.Off],
            colors: ['rgb(0, 227, 150)', 'rgb(255, 69, 96)'],
            labels: ["Online", "Offline"],

            responsive: [{
                breakpoint: 480,
                options: {
                    chart: {
                        width: 200
                    },
                    legend: {
                        position: "bottom"
                    }
                }
            }],
            plotOptions: {
                pie: {
                    donut: {
                        labels: {
                            show: true,
                            name: {
                                show: true,
                                fontSize: '29px',
                                fontFamily: 'Nunito, sans-serif',
                                color: undefined,
                                offsetY: -10
                            },
                            value: {
                                show: true,
                                fontSize: '26px',
                                fontFamily: 'Nunito, sans-serif',
                                color: '20',
                                offsetY: 16,
                                formatter: function(val) {
                                    return val
                                }
                            },
                            total: {
                                show: true,
                                showAlways: true,
                                label: 'Total',
                                color: '#888ea8',
                                formatter: function(w) {
                                    return w.globals.seriesTotals.reduce(function(a, b) {
                                        return a + b
                                    }, 0)
                                }
                            }
                        }
                    }
                }
            }
        };


        return PieChartOptions;
    }

    EMap(O) {
        var TD = this.TD.toLocaleDateString();
        this.ST.put({ RTPDate: TD, UL: O })
        var RTG = $("#RTG");
        RTG.find("tbody tr").remove();

        RTG.find("tbody").append(
            O.map(I => {
                var tr = $("<tr></tr>")
                tr.append(
                    Object.keys(I).map(M => {
                        if (M != "last_changed")
                            return $("<td class='rtg-" + M + "'><div class='" + I[M] + "'>" + (M == "User" ? I[M] : "") + "</div></td>")
                    })
                );
                return tr;
            })
        );

        var chart = new ApexCharts(
            document.querySelector(".us-chart"),
            this.DCO()
        );

        return chart.render();

    }

}

var myfb = {
    config: {
        apiKey: "AIzaSyCvbX0LokLNMoKAjFSpPpRNLPm0QcOND2Q",
        authDomain: "disputed-7c0c3.firebaseapp.com",
        databaseURL: "https://disputed-7c0c3.firebaseio.com",
        projectId: "disputed",
        storageBucket: "disputed.appspot.com",
        messagingSenderId: "189172923440",
        appId: "1:189172923440:web:e33eb9628377da5ef181f5"
    },
    setRealTimePresence: function() {
        var uid = this.AUTH.currentUser.email.split("@")[0].replace(".", "-")

        var userStatusDatabaseRef = firebase.database().ref('/status/' + uid);

        // We'll create two constants which we will write to 
        // the Realtime database when this device is offline
        // or online.
        var isOfflineForDatabase = {
            state: 'offline',
            last_changed: firebase.database.ServerValue.TIMESTAMP,
        };

        var isOnlineForDatabase = {
            state: 'online',
            last_changed: firebase.database.ServerValue.TIMESTAMP,
        };

        // Create a reference to the special '.info/connected' path in 
        // Realtime Database. This path returns `true` when connected
        // and `false` when disconnected.
        firebase.database().ref('.info/connected').on('value', function(snapshot) {
            // If we're not currently connected, don't do anything.
            if (snapshot.val() == false) {
                return;
            };

            // If we are currently connected, then use the 'onDisconnect()' 
            // method to add a set which will only trigger once this 
            // client has disconnected by closing the app, 
            // losing internet, or any other means.
            userStatusDatabaseRef.onDisconnect().set(isOfflineForDatabase).then(function() {
                // The promise returned from .onDisconnect().set() will
                // resolve as soon as the server acknowledges the onDisconnect() 
                // request, NOT once we've actually disconnected:
                // https://firebase.google.com/docs/reference/js/firebase.database.OnDisconnect

                // We can now safely set ourselves as 'online' knowing that the
                // server will mark us as offline once we lose connection.
                userStatusDatabaseRef.set(isOnlineForDatabase);
            }).catch(E => {
                console.log(E)
            })
        });

    },
    getRealtimePresence: function(U) {
        this.RTP = new RealTimePresence(firebase.database(), U, "RTP");
        this.RTP.getOnce(U);
    },
    init: function() {
        firebase.initializeApp(this.config);
        this.db = firebase.firestore();
        this.db.settings({
            cacheSizeBytes: firebase.firestore.CACHE_SIZE_UNLIMITED,
        });
        this.db.enablePersistence();
        this.AUTH = firebase.auth();
        this.loginstate = $("#loginstate");
        this.username = $("#username");
        this.updatesHistory = $("#updatesHistory");
        //this.ui = new firebaseui.auth.AuthUI(this.AUTH);
        this.loginstate.on("click", this.onLoginStateClicked.bind(this));

    },
    ui: null,
    fbcontainer: "#firebaseui-auth-container",
    signOut: function() {
        this.unsubscribe();
        this.changeLoginLinks(0);
        return this;
    },
    onLoginStateClicked: function(event) {

        $('#loginModal').modal('hide');
        $('#messageModalLabel').html(spanText('<i class="fa fa-cog fa-spin"></i>', ['center', 'info']));
        $('#messageModal').modal('show');

        if ($('#loginEmail').val() != '' && $('#loginPassword').val() != '') {
            //login the user
            var data = {
                email: $('#loginEmail').val(),
                password: $('#loginPassword').val()
            };
            $('#messageModalLabel').html(spanText('Logging in..!', ['center', 'success']))
            this.AUTH.setPersistence(firebase.auth.Auth.Persistence.LOCAL).then(function() {
                return myfb.AUTH.signInWithEmailAndPassword(data.email, data.password)
                    .then(function(authData) {
                        console.log(authData)
                        $('#messageModalLabel').html(spanText('Success!', ['center', 'success']))
                        $('#messageModal').modal('hide');
                    })
                    .catch(function(error) {
                        showSnackbar("Login Failed!:-" + error.message, "danger");
                        $('#messageModalLabel').html(spanText('ERROR: ' + error.code, ['danger']))
                    });
            });
        }
    },
    changeLoginLinks: function(loginstate) {
        var anchor = $('#showLoginModal');
        var ancParent = anchor.parent();
        var extlinks = $(".extlinks")
        var svg = $(".user-info svg")
        if (loginstate == 1) {

            ancParent.addClass("d-none")
            ancParent.next().removeClass("d-none")
            if (NETWORK_DISABLED == false) {
                $("#logout").removeClass("disabled");
                svg.eq(1).removeClass("d-none")
                svg.eq(0).addClass("d-none")
            }

            extlinks.each((i, r) => {
                $(r).removeClass("disabled")
            })
        } else {
            ancParent.removeClass("d-none")
            ancParent.next().addClass("d-none")
            svg.eq(1).addClass("d-none")
            svg.eq(0).removeClass("d-none")
            $("#logout").addClass("disabled")
            extlinks.each((i, r) => {
                $(r).addClass("disabled")
            })
        }
        return this;
    },
    onAuthStateChanged: function(user) {

        $.blockUI(this.blockUIOptions)

        function authenticated() {
            $('body').removeClass('auth-false').addClass('auth-true');
            $(".no-access").addClass("d-none").html("")
            $(".inner-content").removeClass("d-none");
            this.changeLoginLinks(1)

            if (user.photoUrl) {
                $('.user-info img').show();
                $('.user-info img').attr('src', user.photoUrl);
                $('.user-info .user-name').hide();
            } else {
                $('.user-info img').show();
                $('.user-info span').text(user.displayName)
            }
            //this.username.text(user.displayName);
            //this.loginstate.children().eq(0).children().eq(1).text("Logout");
            //this.loginstate.children().eq(0).children().eq(0).text("verified_user");

            this.currentUser = user;
            //this.getRealtimePresence();
            $.unblockUI();

        }

        function unauthenticated() {
            $('body').removeClass('auth-true').addClass('auth-false');
            this.changeLoginLinks(0)
            $('.user-info span').text('');
            $(".inner-content").addClass("d-none");
            $(".no-access").html("<img src='./assets/img/unauth-800x800.svg' style='height: 600px; width: 600px' class='d-block mx-auto img-responsive'>").addClass().removeClass("d-none")
            ipcRenderer.send("subscribed", false)
            $.unblockUI();
        }
        if (user) {
            authenticated.apply(myfb)
            this.checkUserStatus(user);
        } else {
            unauthenticated.apply(this)
        }

    },
    checkUserStatus: async function(U) {

        var settings;

        if (NETWORK_DISABLED) {
            settings = await this.db.collection("settings").get({ source: 'cache' });
        } else {
            settings = await this.db.collection("settings").get();
        }

        if (settings) {
            settings.docs.forEach(Doc => {
                Settings[Doc.id] = Doc.data();
            });
            var userIsAdmin = Settings.checkUserIsAdmin(U);
            if (userIsAdmin) {
                this.subscribe();
                this.getRealtimePresence(Settings.systemSettings.users)
                ipcRenderer.send("subscribed", true);
            } else {

                ipcRenderer.send("subscribed", false);
                this.showNoAdmin();
            }
        }

    },
    collection: "disputes",
    unSubscriber: null,
    batchUpdate: function(updates) {
        const upl = updates.length;
        let itemsUpdated = 0;
        let updateErrors = []

        const allItemsUpdated = setInterval(() => {
                if (upl == (itemsUpdated + updateErrors.length)) {
                    ipcRenderer.send("db:onAfterEditExisting", { itemUpdated: itemsUpdated, updateError: updateErrors, total: upl })
                    clearInterval(allItemsUpdated)
                } else {
                    showSnackbar("Still updating items in firestore...!", "info")
                }
            }, upl * 1000) // Assuming 1 second for each item 

        for (var z = 0; z < upl; z++) {
            var docToUpdate = updates[z]
            this.db.collection(this.collection).doc(docToUpdate.InvoiceNo).update({
                ReopenedTimes: docToUpdate.ReopenedTimes,
                Comment: docToUpdate.Comments,
                Status: docToUpdate.Status
            }).then(function() {
                itemsUpdated += 1;
            }).catch(err => {
                updateErrors.push(err)
            })
        }
    },
    fireStoreTimeStamp: function(fromDate) {
        if (typeof fromDate == "string") { fromDate = new Date(fromDate) }
        const aDate = fromDate ? fromDate : new Date()
        return firebase.firestore.Timestamp.fromDate(aDate)
    },
    useConverter: function(item) {
        if (!item) return;
        delete item._id;
        item.FactItemAllocatedOn = this.fireStoreTimeStamp();
        const numberItems = ["Balance", "Paid", "Receivable", "AgingDays"];
        const dateItems = ["DueDate", "InvoiceDate"];

        numberItems.forEach((numberItem, idx) => {
            item[numberItem] = item[numberItem] ? Number(item[numberItem]) : 0
        })
        dateItems.forEach((dateItem, index) => {
            item[dateItem] = item[dateItem] ? this.fireStoreTimeStamp(item[dateItem]) : ""
        })
        return item;
    },
    allocate: async function(itemsToAdd) {

        var CC = Settings.users.getUserCapacity(),
            ccKeys = new Map(Object.entries(CC)),
            // Total Disputes by Bound
            TDBB = SQLike.q({
                Select: ["Bound", "|count|", "Bound"],
                From: inBuilt.data,
                GroupBy: ["Bound"]
            }),
            UABB = SQLike.q({
                Select: ["FactItemAllocatedTo", "Bound", "|count|", "Bound"],
                From: inBuilt.data,
                GroupBy: ["FactItemAllocatedTo", "Bound"]
            });

        var len = itemsToAdd.length;

        //var allocated = await Settings.users.getTotalAllocation();

        function updateAllocated(email, bound, count) {
            //allocated[bound] += count;
            //allocated.Total += count;
            CC[email][bound].allocated += count;
        }

        // Customer alignment
        for (var i = 0; i < len; i++) {
            for (var z = 0; z < ccKeys.length; z++) {
                var email = ccKeys[z].key
                var custlist = CC[email].Customers;
                if (!custlist || custlist.length == 0 || itemsToAdd[i].FactItemAllocatedTo != "") continue;
                if (custlist.join(",").indexOf(itemsToAdd[i].ParentName) != -1) {
                    itemsToAdd[i].FactItemAllocatedTo = email
                    updateAllocated(email, itemsToAdd[i].Bound, 1)
                    break;
                }
            }
        }

        // Outright remove users who have been over allocated because of customer alignment
        // Create new Maps for End to End allocation visibility
        // Allocation Ratio of Capacity vs allocated
        var ARC = new Map();

        for (var [E, V] of ccKeys.entries()) {

            // Total allocated, including the new items from customer allocation
            var KV = Object.keys(V),
                KVL = KV.length;

            for (var Z = 0; Z < KVL; Z++) {

                var B = KV[Z]

                if (B.match(/customers|regions/i)) continue;

                // Capacity for that bound
                if (V[B].capacity == 0) {
                    V[B].AL = 0;
                    V[B].TV = 0;
                    V[B].SBA = 0;
                    V[B].AR = 0;

                } else {

                    V[B].AL = SQLike.q({ // Already allocated to this user for this bound
                        Select: ["count_Bound"],
                        From: UABB,
                        Where: function() { return this.FactItemAllocatedTo == E && this.Bound == B }
                    }).concat(SQLike.q({
                        Select: ["|count|", "Bound"],
                        From: itemsToAdd,
                        Where: function() { return this.FactItemAllocatedTo == E && this.Bound == B }
                    })).reduce((A, C) => {
                        return A + C.count_Bound
                    }, 0);

                    V[B].TV = SQLike.q({ // Total allocation for that Bound
                        Select: ["count_Bound"],
                        From: TDBB,
                        Where: function() { return this.Bound == B }
                    }).concat(SQLike.q({
                        Select: ["|count|", "Bound"],
                        From: itemsToAdd,
                        Where: function() { return this.Bound == B }
                    })).reduce((A, C) => {
                        return A + C.count_Bound
                    }, 0);

                    V[B].SBA = V[B].TV == 0 ? 0 : Math.round(V[B].TV * V[B].capacity / 100) // Should be allocated

                    V[B].AR = V[B].SBA - V[B].AL // + - difference of allocated to should be allocated
                        // If SBA > Allocated, then opportunity to Allocate
                }

            };
            ccKeys.set(E, V);
        }

        // Get User associated by a certain bound and region
        function getUATBR(B, R) {
            var RES = [];
            // Loop by each user
            for (var [email, user] of ccKeys.entries()) {
                var ISR = true,
                    ISB = false
                if (R) {
                    if (user.Regions.join(",").indexOf(R) == -1) ISR = false;
                }
                // User must have a capacity allocated > 0 and there must be room for allocation
                if (user[B].capacity > 0 && user[B].AR > 0) ISB = true
                if (ISR && ISB) {
                    user.empEmail = email;
                    RES.push(user)
                }
            }
            RES.sort(function(a, b) {
                return a[B].AR - b[B].AR
            });
            return RES;
        }

        // Then by bound and region for new items
        var boundCount = SQLike.q({
            Select: ["Bound", "Region", "|count|", "Bound"],
            From: itemsToAdd,
            GroupBy: ["Bound", "Region"]
        });

        boundCount.forEach((boundItem, idx) => {

            var bound = boundItem.Bound,
                region = boundItem.Region,
                BIC = boundItem.count_Bound

            // Get a list of users whose capacity for a given bound is > 0
            // Users associated with this bound and region
            var UATB = getUATBR(bound, region);

            // Not 100% of the users will be returned and since their individual contribution 
            // may not add up to 100%, we will need to buffer the difference in their allocation


            // Assign work items to each user associated with the bound and region
            UATB.forEach((user, idx) => {
                // Distribution of work by number of regions allocated
                if (BIC <= 0) return;

                var UCTTW = user.AR //usersCapacityToTakeWork(user[bound].capacity, BIC, ED[idx]);

                if (UCTTW > BIC) UCTTW = BIC;
                // This is my very own intelligent array update function :))
                itemsToAdd = updateWhere(
                    itemsToAdd,
                    function() { // Where
                        return this.Bound == bound &&
                            this.Region == region &&
                            this.FactItemAllocatedTo == ""
                    },
                    function() { // Set
                        this.FactItemAllocatedTo = user.empEmail
                    },
                    UCTTW // Limit
                )

                BIC -= UCTTW;

                // Update local data
                updateAllocated(user.empEmail, bound, UCTTW)
                    //totalAssigned += UCTTW

            })

        }); // End boundCount loop

        /*
        There might still be items which didn't get allocated
        due to rounding off or descrepencies in Bound or Region settings
        Therefore we do a second set of allocation as a failsafe
        Here we can do a equal distribution
        */
        var unallocated = SQLike.q({
            Select: ["Bound", "|count|", "Bound"],
            From: itemsToAdd,
            Where: function() { return this.FactItemAllocatedTo == "" },
            GroupBy: ["Bound"],
            Sort: ["Bound", "|desc|"]
        });

        unallocated.forEach(UAI => {

            var bound = UAI.Bound;

            if (bound) {

                var UATB = getUATBR(bound);

                var ED = [];

                for (let D of distributeInteger(UAI.count_Bound, UATB.length)) ED.push(D)

                UATB.forEach((U, I) => {
                    if (ED[I] > 0) {
                        itemsToAdd = updateWhere(
                                itemsToAdd,
                                // Where function
                                function() { return this.Bound == bound && this.FactItemAllocatedTo == "" },
                                // Set function
                                function() { this.FactItemAllocatedTo = U.empEmail },
                                // limit
                                ED[I]
                            )
                            // Update local data
                        updateAllocated(U.empEmail, bound, ED[I])
                    }
                });

            }

        })

        // Hopefully by now all the items have been allocated
        // But there is a lot of data manipulation happening which
        // also depends how nicely the users info is set up
        // Last fallback - return only the ones which are allocated
        // The rest can be taken care of in the next allocation cycle

        var ret = itemsToAdd.filter(i => {
            return i.FactItemAllocatedTo != ""
        });

        // return allocation data
        return ret

    },
    updateSettingsInFireStore: function(doc, value) {

        return this.db.collection("settings").doc(doc).update(value)

    },
    batchAdd: async function(docsToAdd) {
        const adl = docsToAdd.length;

        if (!adl) return;

        const batch = this.db.batch();
        const updates = []
        let docRef;

        docsToAdd = await this.allocate(docsToAdd);

        for (var i = 0; i < adl; i++) {
            if (docsToAdd[i].hasOwnProperty("isAnUpdate")) {
                delete docsToAdd[i].isAnUpdate
                updates.push(docsToAdd[i]);
                continue;
            }
            var docToAdd = this.useConverter(docsToAdd[i])
            docRef = this.db.collection(this.collection).doc(docToAdd.InvoiceNo);
            batch.set(docRef, docToAdd);
        }
        batch.commit().then(done => {
            ipcRenderer.send("db:batchAdded", {
                added: docsToAdd
            })
        }).catch(err => {
            ipcRenderer.send("db:batchAdded", {
                err: err
            })
        })
        if (updates.length) this.batchUpdate(updates)

    },
    unsubscribe: function() {
        this.db.disableNetwork();
    },
    subscribe: function() {

        this.unSubscriber =
            this.db.collection(this.collection).onSnapshot({ includeMetadataChanges: true },
                function(snapshot) {
                    const changes = [];
                    snapshot.docChanges().forEach(function(change) {
                        changes.push({
                            doc: change.doc.data(),
                            id: change.doc.id,
                            type: change.type,
                            fromCache: snapshot.metadata.fromCache,
                            hasPendingWrites: snapshot.metadata.hasPendingWrites
                        })
                    });
                    if (changes.length) {
                        ipcRenderer.send("db:onSnapshot", changes);
                        inBuilt.set(changes);
                    }
                }
            );

        this.settingsUnSubscriber = this.db.collection("settings").onSnapshot({
                includeMetadataChanges: true
            },
            function(snapshot) {
                const changes = [];
                snapshot.docChanges().forEach(function(change) {
                    if (!snapshot.metadata.fromCache) {
                        changes.push({
                            doc: change.doc.data(),
                            id: change.doc.id,
                            type: change.type
                        })
                    }
                });
                Settings.applyChanges(changes)
            });
        Settings.init()


    },
    blockUIOptions: {
        fadeIn: 800,
        message: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#FF149F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-loader"><line x1="12" y1="2" x2="12" y2="6"></line><line x1="12" y1="18" x2="12" y2="22"></line><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"></line><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"></line><line x1="2" y1="12" x2="6" y2="12"></line><line x1="18" y1="12" x2="22" y2="12"></line><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"></line><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"></line></svg>',
        overlayCSS: {
            backgroundColor: '#1b2024',
            opacity: 0.8,
            zIndex: 1200,
            cursor: 'wait'
        },
        css: {
            border: 0,
            color: '#fff',
            zIndex: 1201,
            padding: 0,
            backgroundColor: 'transparent'
        }
    },
    registerFormSubmit: function() {
        $('#registerModal').modal('hide');
        $('#messageModalLabel').html(spanText('<i class="fa fa-cog fa-spin"></i>', ['center', 'info']));
        $('#messageModal').modal('show');
        var data = {
            email: $('#registerEmail').val(), //get the email from Form
            firstName: $('#registerFirstName').val(), // get firstName
            lastName: $('#registerLastName').val(), // get lastName
        };
        var passwords = {
            password: $('#registerPassword').val(), //get the pass from Form
            cPassword: $('#registerConfirmPassword').val(), //get the confirmPass from Form
        }
        if (data.email != '' && passwords.password != '' && passwords.cPassword != '') {
            if (passwords.password == passwords.cPassword) {
                //create the user

                this.AUTH
                    .createUserWithEmailAndPassword(data.email, passwords.password)
                    .then(function(NewUser) {
                        if (!NewUser.updateProfile && NewUser.hasOwnProperty("user")) {
                            NewUser = NewUser.user
                        }
                        return NewUser.updateProfile({
                            displayName: data.firstName + ' ' + data.lastName
                        })
                    })
                    .then(function(user) {
                        //now saving the profile data
                        $('#messageModalLabel').html(spanText('Success!', ['center', 'success']))
                        $('#messageModal').modal('hide');
                    })
                    .catch(function(error) {
                        showSnackbar("Error creating user:" + error.message, "danger");
                        $('#messageModalLabel').html(spanText('ERROR: ' + error.code, ['danger']))
                    });
            } else {
                //password and confirm password didn't match
                $('#messageModalLabel').html(spanText("ERROR: Passwords didn't match", ['danger']))
            }
        }
    }
};

let distributeInteger = function*(total, divider) {
    if (divider === 0) {
        yield 0
    } else {
        let rest = total % divider
        let result = total / divider

        for (let i = 0; i < divider; i++) {
            if (rest-- > 0) {
                yield Math.ceil(result)
            } else {
                yield Math.floor(result)
            }
        }
    }
}

var bglist = {
    success: '#8dbf42',
    warning: '#e2a03f',
    danger: '#e7515a',
    dark: '#3b3f5c',
    primary: '#1b55e2',
    info: '#2196f3'
}

function showSnackbar(snackText, type) {
    Snackbar.show({
        text: snackText,
        actionTextColor: '#fff',
        backgroundColor: bglist[type]
    });
}

const updateWhere = function(arr, where, set, limit) {
    var len = arr.length;
    for (var z = 0; z < len; z++) {
        if (where) {
            if (where.apply(arr[z])) {
                set.apply(arr[z])
                if (limit) {
                    limit--;
                    if (limit == 0) break;
                }
            }
        } else {
            set.apply(arr[z])
            if (limit) {
                limit--;
                if (limit == 0) break;
            }
        }
    }
    return arr;
}

const resourcesPath = process.env.NODE_ENV == "production" ? process.resourcesPath : __dirname

function getOffsetBetweenTimezonesForDate(date) {
    if (!date) date = new Date();
    var timezone1 = "Asia/Manila",
        timezone2 = "America/New_York"
    const timezone1Date = convertDateToAnotherTimeZone(date, timezone1);
    const timezone2Date = convertDateToAnotherTimeZone(date, timezone2);
    const utcdiff = timezone1Date.getTime() - timezone2Date.getTime();
    return new Date(date.getTime() - utcdiff)
}

function convertDateToAnotherTimeZone(date, timezone) {
    const dateString = date.toLocaleString('en-US', {
        timeZone: timezone
    });
    return new Date(dateString);
}

var Settings = {
    init: function() {
        this.motherElement = $(".settings-tab");
        var allsettings = ["systemSettings", "opusFieldMap", "disputeMap"]
        allsettings.forEach((S, I) => {
            Settings.item(Settings[S], S, I)
        });
        this.initialized = true;
        return this;
    },
    isInitialized: false,
    showReminderBox: function() {
        $("#reminderModal").modal("show");
    },
    applyChanges: function(changes) {

        changes.forEach(change => {
            if (change.id == "systemSettings") {
                Settings.update({
                    key: { item: "systemSettings" },
                    updateval: { $set: { "data": change.doc } },
                    successText: "User data has been updated from the server! Please check the latest users list",
                    header: "user"
                });

            } else if (change.id == "opusFieldMap") {
                Settings.update({
                    key: { item: "opusFieldMap" },
                    updateval: { $set: { "data": change.doc } },
                    successText: "Latest field mapping is available from Opus",
                    header: "opus"
                });
            } else if (change.id == "disputeMap") {
                Settings.update({
                    key: { item: "disputeMap" },
                    updateval: { $set: { "data": change.doc } },
                    successText: "Latest dispute mapping is available",
                    header: "opus"
                });
            }
        });
        if (changes.length) {
            Settings.users.createCapacitytable(Settings.systemSettings.users);
            Settings.users.createUsertable(Settings.systemSettings.users)
        }
    },
    checkUserIsAdmin: function(user) {
        var isAdmin = this.systemSettings.users.filter(U => {
            return (U.empEmail == user.email) && U.role.toLowerCase().match("admin") != undefined
        });
        return isAdmin.length ? 1 : 0
    },
    update: function(settingsItem) {
        return ipcRenderer.send(
            "update:settings",
            settingsItem
        )
    },
    users: {
        getTotalAllocation: async function() {
            //var allocationDate = "TotalAllocation-" + this.getAllocationDate();
            var totalAllocation = await AS.DWA.get({ AllocationDate: this.getAllocationDate() });
            if (!totalAllocation) {
                totalAllocation = await this.setTotalAllocation({ Import: 0, Export: 0, Detention: 0, Demurrage: 0, Others: 0, Total: 0 })
            }
            return totalAllocation
        },
        setTotalAllocation: async function(TotalAllocation) {
            var allocationDate = this.getAllocationDate();
            TotalAllocation.AllocationDate = allocationDate
            var totalAllocation = await AS.DWA.put(TotalAllocation);
            return totalAllocation;
        },
        getCapacity: async function() {
            var allocationDate = this.getAllocationDate();
            var capacity = await this.getAllocationFromLocal(allocationDate);
            return capacity
        },
        setCapacity: async function(value) {
            var allocationDate = this.getAllocationDate();
            var item2Set = await this.setAllocationToLocal(allocationDate, value);
        },
        allocationDate: null,
        getAllocationDate: function() {
            if (!this.allocationDate) {

                this.allocationDate = getOffsetBetweenTimezonesForDate()
            }
            return this.allocationDate;
        },
        setAllocationToLocal: async function(key, value) {
            var itemToSet = await allocationStore.setItem(key, value).then(res => { return res });
            return itemToSet;
        },
        getAllocationFromLocal: async function(key) {
            var todaysAllocation = await AS.DWA.get({ AllocationDaye: key }).first();
            if (!todaysAllocation) {
                todaysAllocation = await this.setAllocationToLocal(key, this.getUserCapacity())
            }
            return todaysAllocation
        },
        getUserCapacity: function() {
            var ret = {}
            Settings.systemSettings.users.forEach(user => {
                var skills = user.Skills;
                ret[user.empEmail] = {};
                Object.assign(ret[user.empEmail], ret[user.empEmail], Object.keys(skills).forEach(skill => {
                    if ($.isArray(skills[skill])) {
                        ret[user.empEmail][skill] = skills[skill]
                    } else {
                        ret[user.empEmail][skill] = { capacity: parseInt(skills[skill]), allocated: 0 }
                    }
                }));
            })
            return ret
        },

        saveUser: function(userdata) {
            $.blockUI(myfb.blockUIOptions);

            var data = { Skills: {} }
            var M = $("#userModal"),
                FC = M.find(".form-control"),
                ISN = M.data("new");

            if (ISN) {
                var MD = M.find('[data-mandatory]');
                var AW = true,
                    ER = [];
                MD.each((I, E) => {
                    if (E.getAttribute("data-mandatory") == 0) return;
                    if (!E.value) {
                        $(E).addClass("VE");
                        ER.push(E.getAttribute("placeholder"))
                        AW = false;
                    } else {
                        $(E).removeClass("VE");
                    }
                });
                if (!AW) {
                    var ERM = "<h4>Mandatory information is missing</h4><ul class='list-group>'"
                    ER.forEach(ERS => { ERM += "<li class='list-item'>" + ERS + "</li>" });
                    ERM += "</ul>"
                    showSnackbar(ERM, "danger");
                    $.unblockUI()
                    return;
                }
            }
            FC.each(function(idx, item) {
                var attr = $(item).attr("data-key"),
                    val;
                if (attr.match("Skills")) {
                    val = $(item).val()
                    if ($(item).prop("nodeName") == "TEXTAREA") {
                        val = val ? $(item).val().split("\n") : []
                    }
                    data.Skills[attr.replace("Skills.", "")] = val
                } else {
                    if (attr == "role") {
                        data[attr] = $(item).val().join("|")
                    } else {
                        data[attr] = $(item).val();
                    }
                }
            });


            for (var SE, z = 0; z < Settings.systemSettings.users.length; z++) {
                if (Settings.systemSettings.users[z].empEmail == data.empEmail) {
                    if (ISN) {
                        SE = true;
                    } else {
                        Settings.systemSettings.users[z] = data;
                    }
                    break;
                }
            }

            if (SE) return showSnackbar("Similar email already exists, please double check and try again", "danger"), $.unblockUI();

            if (ISN) Settings.systemSettings.users.push(data)

            myfb.updateSettingsInFireStore("systemSettings", { users: Settings.systemSettings.users }).then(update => {
                if (ISN) showSnackbar("Added a new user to list", "success")
            }).catch(err => {
                showSnackbar("Apologies: Error Updating user", "danger")

            });

            $("#userModal").modal("hide")
            $.unblockUI();

            if (NETWORK_DISABLED) {
                showSnackbar("Not connected currently! Firestore will update when you are back online!");
            }


        },
        editUser: function(row, userdata, action) {

            if (action.toLowerCase() == "remove") {

                var CF = window.confirm("Do you really want to delete this user??", "Remove user")

                if (!CF) return;

                for (var SE, z = 0; z < Settings.systemSettings.users.length; z++) {
                    if (Settings.systemSettings.users[z].empEmail == userdata.empEmail) {
                        Settings.systemSettings.users.splice(z, 1)
                        break;
                    }
                }

                myfb.updateSettingsInFireStore("systemSettings", { users: Settings.systemSettings.users }).then(update => {
                    showSnackbar("User removed from list!")
                }).catch(err => {
                    showSnackbar("Apologies: Error Updating user", "danger")
                });

                return;

            }

            var userModal = $("#userModal");

            Object.keys(userdata).forEach(function(useritem, idx) {
                if (useritem == "Skills") {
                    Object.keys(userdata[useritem]).forEach(skill => {
                        var thiselem = userModal.find(`[data-key='Skills.${skill}']`);
                        thiselem.val(userdata.Skills[skill])
                    })
                } else {
                    var thiselem = userModal.find(`[data-key='${useritem}']`);
                    thiselem.val(userdata[useritem])
                }
            })
            userModal.modal("show").data("new", false).data("data", userdata)
            return 1;
        },

        saveCapacity: function() {
            $.blockUI(myfb.blockUIOptions);
            var rows = $(".capacity").find("tr");
            var users = Settings.systemSettings.users;
            var dataToUpdate = {},
                changes = [],
                CD = new Date().getTime()
            $.each(rows, function(index, row) {
                var empid = $(row).data("empid");
                var categorydata = {}
                $(row).children().each((index, child) => {
                    var dataCategory = child.getAttribute("data-category");
                    var ret = {}
                    if (dataCategory) {
                        var RC = child.querySelector("input.progress-range-counter")
                        categorydata[dataCategory] = RC.value;
                        var OV = Number(RC.getAttribute("data-org"))
                        if (RC.value != OV) {
                            changes.push({ CD: CD, U: empid.email, B: dataCategory, OV: OV, NV: RC.value })
                        }
                    }
                });
                dataToUpdate[empid.id] = categorydata;
            });

            users = users.map(user => {
                var ns = dataToUpdate[user.empID]
                Object.assign(user.Skills, user.Skills, ns)
                return user
            });

            Settings.systemSettings.users = users;

            myfb.updateSettingsInFireStore("systemSettings", { users: Settings.systemSettings.users }).then(update => {

            }).catch(err => {
                showSnackbar("Apologies: Error Updating user", "danger")
            });

            AS.transaction("rw", [AS.CAPCH, AS.REM], async() => {
                await AS.CAPCH.bulkAdd(changes);
                await AS.REM.put({ R: "Capacity Modified", ED: CD }) // RD = Reminder description, ED - Event date
                $(".rembadge").removeClass("d-none");
            }).then(() => {
                showSnackbar("Capacity change available in the notification panel!", "info", "top-center")
            });
            $.unblockUI();

            if (NETWORK_DISABLED) {
                showSnackbar("Not connected! Firestore will update when you're back online!")
            }

            return;
        },
        createCapacitytable: function(userlist) {
            var capacity = SQLike.q({
                Select: ["empName", "|as|", "UserName",
                    "empID", "|as|", "Id",
                    "empEmail", "|as|", "Email",
                    function() { return parseInt(this.Skills.Import) }, "|as|", "Import",
                    function() { return parseInt(this.Skills.Export) }, "|as|", "Export",
                    function() { return parseInt(this.Skills.Detention) }, "|as|", "Detention",
                    function() { return parseInt(this.Skills.Demurrage) }, "|as|", "Demurrage",
                    function() { return parseInt(this.Skills.Others) }, "|as|", "Others"
                ],
                from: userlist,
                OrderBy: ["empID", "|desc|"]
            });

            $(".capacity").empty();

            var slider = function() {
                return $(
                    `<div class="custom-progress progress-up" style="width: 100%">
                        <div class="range-count"><span class="range-count-number" contenteditable data-rangecountnumber="0">0</span> <span class="range-count-unit">%</span></div>
                        <input type="range" min="0" max="40" class="custom-range progress-range-counter">
                    </div>`
                )
            }

            capacity.forEach((cap, id) => {
                function getslider(val) {
                    var newslider = slider();
                    newslider.find("input").attr("value", val).attr("data-org", val)
                    var rngCount = newslider.find(".range-count-number");
                    rngCount.attr("data-rangecountnumber", val)
                    rngCount.html(val)
                    return newslider[0].outerHTML
                }

                $(".capacity").append(
                    $("<tr></tr>").html(
                        '<td><div class="range-count"><span class="range-count-number">' + (cap.Export + cap.Import + cap.Demurrage + cap.Detention + cap.Others) + '</span><span class="range-count-unit">%</span></div>' + cap.UserName + "</td>" +
                        "<td data-category='Export'>" + getslider(cap.Export) + "</td>" +
                        "<td data-category='Import'>" + getslider(cap.Import) + "</td>" +
                        "<td data-category='Detention'>" + getslider(cap.Detention) + "</td>" +
                        "<td data-category='Demurrage'>" + getslider(cap.Demurrage) + "</td>" +
                        "<td data-category='Others'>" + getslider(cap.Others) + "</td>"
                    ).data("empid", { id: cap.Id, email: cap.Email })
                )

                $(".capacity").parent().find("thead th").each(function(idx, th) {
                    if ($(th).children()) {
                        var rngCount = $(th).find(".range-count-number");
                        var dAttr = rngCount.attr("data-category")
                        var total = 0;
                        $(".capacity").find("td[data-category='" + dAttr + "']").each(function(idx, td) {
                            total += parseInt(td.querySelector("input").value);
                        })
                        rngCount.html(total);
                    }
                })
            });

            progressBarCount('.progress-range-counter');

            function progressBarCount($progressCount) {
                var elements = document.querySelectorAll($progressCount);
                for (var i = 0; i < elements.length; i++) {
                    elements[i].addEventListener('input', function(event) {
                        var getValueOfRangeSlider = this.value;
                        var getParentElement = this.closest(".custom-progress").querySelector('.range-count-number');
                        var tdparent = this.closest("td");
                        var attr = tdparent.getAttribute("data-category");
                        var rangesInRow = $(tdparent).parent().find("input")
                        var setValueOfRangeCountValue = getParentElement.innerHTML = getValueOfRangeSlider;
                        var setValueOfAttributeValue = getParentElement.setAttribute("data-rangeCountNumber", getValueOfRangeSlider)
                        var catSpan = document.querySelector("th span[data-category='" + attr + "'");
                        var userSpan = $(tdparent).parent().children().eq(0).find(".range-count-number")[0]
                        var totalCol = 0,
                            totalRow = 0;
                        $(".capacity td[data-category='" + attr + "'").each(function(idx, td) {
                            totalCol += parseInt(td.querySelector("input").value);
                        });
                        rangesInRow.each((index, range) => {
                            totalRow += parseInt(range.value)
                        })
                        userSpan.innerHTML = totalRow //Math.round(totalRow * (100 / rangesInRow.find("input[value != '0']").length) / 100)
                        catSpan.innerHTML = totalCol;
                    });
                }
            }
        },
        createUsertable: function(userlist) {
            var editIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#FF149F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>`
            var tagicon = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#FF149F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-tag"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line></svg>'
            var removeIcon = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#212529" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>'

            var elem = $(`table[data-elem="users"]`);
            var usertable = Settings.makeTable(userlist, ["Skills", tagicon, "revealSkills"], [{ action: "edit", icon: editIcon }, { action: "remove", icon: removeIcon }], "users");
            elem.empty().append(usertable)
        }
    },
    intervals: {
        createIntervalTable(intervals) {
            Object.keys(intervals).forEach((Interval, Idx) => {
                var inp = $("<input class='form-control' style='border: 1px solid aliceblue'>").val(intervals[Interval])
                $(`[data-key="${Interval}"]`).html(inp)
            });
        },
        updateInterval: function(interval, val) {
            Settings.systemSettings.intervals[interval] = val;
            Settings.update({
                key: { item: "systemSettings" },
                updateval: { $set: { "data.intervals": Settings.systemSettings.intervals } },
                successText: "Interval value updated! Will take effect immediately!",
                header: "interval"
            });
        }
    },
    newHeader: function(T) {
        var EM = $("#emptyModal");
        EM.find("#emptyModalTitle").text("Create a new " + T);
        var OL = ["string", "date", "number", "boolean", "object"]
        var F = $("<div class='form'><label for='field'>Name of the new field</label><input name='field' type='text' class='form-control' data-key='field'></form>");
        var S1 = $("<label for='fieldtype'>Type of field</label><select name='fieldtype' data-key='type' class='form-control mt2'></select>")
        OL.forEach(I => {
            S1.filter(".form-control").append("<option value=" + I + ">" + I + "</option>")
        });
        var S2 = "<label for='default'>Default Value</label><input name='default' value='' type='text' class='form-control' data-key='default'>"
        EM.find(".modal-body").empty().append(F.append([S1, S2]))
        var B = $("<button class='btn btn-primary' id='saveheader' onclick=Settings.saveNewHeader()>Save</button>")
        EM.find(".modal-footer").children("#saveheader").remove();
        EM.find(".modal-footer").append(B)
        EM.modal("show");
    },
    saveNewHeader: function(H) {
        var FC = $("#emptyModal .modal-body .form-control");
        var O = {};
        FC.each((I, E) => {
            O[E.getAttribute("data-key")] = E.value
        })
        alert(JSON.stringify(O))

    },
    item: function(s, i, index, id) {

        var dataItems = Object.keys(s);

        if (i == "systemSettings") {
            dataItems.forEach((ITEM, IDX) => {
                if (ITEM == "users") {
                    var userlist = s[ITEM];
                    Settings.users.createUsertable(userlist)
                    Settings.users.createCapacitytable(userlist)
                } else if (ITEM == "fileHeaders") {
                    var FHT = $(".fileheaders");
                    var FHD = s[ITEM]
                    FHT.empty().append($('<table class="table table-responsive"><caption>System Headers <a class="pull-right" href="javascript:void(0)" onclick=Settings.newHeader("fileHeaders")><svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg></a></caption></table>').append(this.makeTable(FHD)))
                } else if (ITEM == "additionalNewHeaders") {
                    var AFH = $(".additionalfileheaders");
                    var AFHD = s[ITEM]
                    AFH.empty().append($('<table class="table table-responsive"><caption>Additional New Headers <a class="pull-right" href="javascript:void(0)" onclick=Settings.newHeader("additionalNewHeaders")><svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg></a></caption></table>').append(this.makeTable(AFHD)))
                }
            });
        } else if (i == "opusFieldMap") {
            Settings.opusMap.create(s)
        } else if (i == "disputeMap") {
            Object.keys(s).forEach(ITEM => {
                var IE = $("." + ITEM.toLowerCase());
                var ID = s[ITEM]
                IE.append($("<table class='table table-responsive'><caption>Dispute " + ITEM + "</caption></table>").append(this.makeTable(ID)));
            })
        }

        return s;


    },
    opusMap: {

        create: function(OMAP) {
            // Get handle of the elem
            var E = $("#v-line-pills-opusmap");
            // Get all tabs from Opusmap
            var OMK = Object.keys(OMAP);
            // Create a Justified Vertical Pill Tab - floating Right
            var jvpr = JVPR(OMK);
            // Get a handle of this object
            var that = this;
            OMK.forEach((MK, MKI) => {
                // Map Object...like Booking, charges etc..
                var MO = $("<ul class='file-tree'></ul>").append(that.mapitem(OMAP[MK], MK))
                jvpr.AppendToTabPane(MKI, MO)
            });

            jvpr.Compile().appendTo(E)

            return this.callListeners();

        },
        callListeners: function() {
            var folder = $('.file-tree li.file-tree-folder'),
                file = $('.file-tree li');

            folder.on("click", function(a) {
                $(this).children('ul').slideToggle(400, function() {
                    $(this).parent("li").toggleClass("open")
                });
                a.stopPropagation();
            })

            file.on('click', function(b) {
                b.stopPropagation();
            })
        },
        // Either you can use an existing Datatag object to read else create a new one
        datatag: function(DOO) {
            // Data tag outer LI
            var DLOI = $(`<li class='file-tree-folder'>Datatag</li>`);

            if (DOO) {
                var ul = $("<ul></ul>");
                DOO.forEach(E => {
                    // E is the individual datatag object element
                    // Data tag individual table LI
                    var DOELI = $(`<li class='file-tree-folder'>${E.tableName}</li>`);
                    // check if the table has fields?
                    if (!E.fields.length) {
                        // It must need items
                        DOELI.addClass("empty")
                    } else {
                        DOELI.append(
                            $("<ul></ul>").append(
                                $("<li></li>").append(
                                    $("<table class='table table-responsive'></table>").append(
                                        Settings.makeTable(E.fields)
                                    )
                                )
                            )
                        )
                    }
                    ul.append(DOELI)
                });
                DLOI.append(ul)
            } else {
                DLOI.addClass("empty")
            }

            return DLOI

        },
        etctag: function(ET) {

            var ETO = $(`<li class='file-tree-folder'>Etctag</li>`);

            if (!ET) {
                ETO.addClass("empty")
            } else {
                ETO.append(
                    $("<ul></ul>").append(
                        $("<li></li>").append(
                            $("<table class='table datatables'></table>").append(
                                Settings.makeTable(ET)
                            )
                        )
                    )
                )
            }
            return ETO
        },
        // mo == Map object, mk = Map key
        // output must be two objects 1. etctag & datatag
        mapitem: function(mo, mk) {
            // Output objects
            var OO = ["datatag", "etctag"];
            // create maps for each element of the Output Element object
            var that = this;
            // Can return an Array containing both elements
            var OP = []
            OO.forEach(OOE => {
                OP.push(that[OOE](mo[OOE] ? mo[OOE] : null))
            })
            return OP
        },

    },
    makeTable: function(tblarr, special, actions, tableof) {
        var hdr = Object.keys(tblarr[0])
        if (actions) hdr.push("Action")
        var thead = $("<thead></thead>")
        var tbody = $("<tbody></tbody>");
        var tr = $("<tr></tr>")
        hdr.forEach(function(h, i) {
            tr.append(`<th>${h}</th>`)
        });

        tr.appendTo(thead);
        for (var z = 0; z < tblarr.length; z++) {
            var thisobj = tblarr[z];
            tr = $("<tr></tr>").data("rowdata", thisobj)
            for (var i = 0; i < hdr.length; i++) {
                if ($.isArray(thisobj[hdr[i]])) {
                    tr.append(Settings.makeTable(thisobj[hdr[i]]))
                } else {
                    if (special && hdr[i] == special[0]) {
                        var anchor = $("<a class='" + special[2] + "'>").data("Skills", thisobj[hdr[i]]).attr("href", "javascript:void(0)").html(special[1])
                        tr.append($("<td class='text-center'>").append(anchor))
                    } else if (actions && hdr[i] == "Action") {
                        var ul = $("<ul class='table-controls'></ul>")
                        var td = $("<td class='text-center'></td>")
                        ul.append(actions.map((action, item) => {
                            var li = $("<li></li>")
                            var anchor = $("<a></a>")
                                .attr("data-of", "users")
                                .attr("href", "javascript:void(0)")
                                .attr("data-toggle", "tooltip")
                                .attr("data-placement", "top")
                                .attr("title", action.action.toProperCase())
                                .html(action.icon)
                                .on("click", function() {
                                    var tr = $(this).closest("tr"),
                                        rowid = tr.index(),
                                        rowdata = tr.data("rowdata"),
                                        dataof = $(this).attr("data-of"),
                                        action = $(this).attr("title")
                                    if (dataof == "users") {
                                        return Settings.users.editUser(rowid, rowdata, action)
                                    }
                                })
                            return li.append(anchor), li;
                        })).appendTo(td)
                        tr.append(td)
                    } else {
                        // var inp = $("<input class='form-control' style='border: 1px solid aliceblue'>").val(thisobj[hdr[i]])
                        tr.append($(`<td>${thisobj[hdr[i]]}</td>`))
                    }
                }
            }
            tr.appendTo(tbody)
        }

        return [thead, tbody]
    },

    makeNewAccordion: function(i, h, d) {
        var acid = new String(Math.random()).substr(3, 6),
            card = $('<div class="card"></div>'),
            cardHeader = $(`<div class="card-header" id="heading-${acid}"></div>`),
            section = $('<section class="mb-0 mt-0"></section>'),
            collapse = $(`<div role="menu" class="" data-toggle="collapse" data-target="#withoutSpacingAccordion${acid}" aria-expanded="true" aria-controls="withoutSpacingAccordion${i}">${h}</div>`),
            collapseCont = $(`<div id="withoutSpacingAccordion${acid}" class="collapse ${i == 0 ? "show" : ""}" aria-labelledby="heading-${acid}" data-parent="#withoutSpacing-${i}"></div>`),
            cardBody = $(`<div class="card-body"></div>`).append(d)

        cardHeader.append(section.append(collapse))
        collapseCont.append(cardBody)
        card.append([cardHeader, collapseCont])

        return card;

    }

}

function JVPR(links) {
    // Outer
    var O = $('<div class="row mb-4 mt-3"></div>')
        // Pill Link Outer
    var PLPO = $('<div class="col-sm-3 col-12"></div>')
        // Pill link Parent
    var PLP = $('<div style="margin-left: 2px!important; margin-right: 2px!important" class="nav flex-column nav-pills mb-sm-0 mb-3" id="v-right-pills-tab" role="tablist" aria-orientation="vertical"></div>')
        // Individual pill links
    var PL = [];
    // Populate each link and tab pane
    var TP = []
    links.forEach((link, idx) => {
        PL.push($(`<a class="nav-link ${ idx==0?'active':''} mb-2" id="v-right-pills-${link}-tab" data-toggle="pill" href="#v-right-pills-${link}" role="tab" aria-controls="v-right-pills-${link}" aria-selected="true">${link}</a>`))
        TP.push($(`<div class="tab-pane fade show ${ idx==0?'active':''}" id="v-right-pills-${link}" role="tabpanel" aria-labelledby="v-right-pills-${link}-tab"><h4>${link.toUpperCase()}</h4><div class='container'></div></div>`))
    });
    // Parent of the content
    var CP = $('<div class="col-sm-9 col-12 order-sm-0 order-1"></div>')
        // Content div 
    var TC = $('<div class="tab-content" id="v-right-pills-tabContent"></div>')

    return {
        Outer: O,
        PillLinkOuter: PLPO,
        PillLinkParent: PLP,
        PillLinks: PL,
        ContentParent: CP,
        TabContent: TC,
        TabPanes: TP,
        AppendToTabPane: function(paneIndex, paneContent) {
            this.TabPanes[paneIndex].find(".container").append(paneContent)
        },
        Compile: function() {
            this.PillLinkParent.append(this.PillLinks).appendTo(this.PillLinkOuter);
            this.TabContent.append(this.TabPanes).appendTo(this.ContentParent);
            this.Outer.append([this.PillLinkOuter, this.ContentParent])
            return this.Outer
        }
    }
}

String.prototype.toProperCase = function() {
    return this.split(" ").map((words, idx) => {
        return words[0].toUpperCase() + words.slice(1).toLowerCase()
    }).join(" ")
}




// Initialize Firebase
myfb.init();

myfb.AUTH.onAuthStateChanged(function(user) {
    return myfb.onAuthStateChanged(user);
});

function daysDifference(d0, d1) {
    var diff = new Date(+d1).setHours(12) - new Date(+d0).setHours(12);
    return Math.round(diff / 8.64e7);
};

/*
* Functions for enabling reading of excel files thru drag and drop

var filereader = {
    input: null,
    filesInput: null,
    drop: null,
    cont: null,
    inEvents: ["dragenter", "dragover"],
    outEvents: ["dragleave", "dragend", "mouseout", "drop"],
    handleIn: function() {
        this.drop.css({
            border: "4px dashed #3023AE",
            background: "rgba(0, 153, 255, .05)",
        });
        this.cont.css({ color: "#3023AE" });
    },
    handleOut: function() {
        this.drop.css({
            border: "3px dashed #DADFE3",
            background: "transparent",
        });

        this.cont.css({ color: "#8E99A5" });
    },
    init: function() {
        var that = this;
        this.input = document.querySelector("input");
        this.filesInput = $("#files");
        this.drop = $(".drop");
        this.cont = $(".cont");
        this.inEvents.forEach((event) =>
            that.drop.on(event, that.handleIn.bind(that))
        );
        this.outEvents.forEach((event) =>
            that.drop.on(event, that.handleOut.bind(that))
        );
        this.filesInput.on("change", that.handleFileSelect.bind(that));
        return;
    },
    handleFileSelect: function() {
        const files = event.target.files;
        for (let file of files) {
            // Only process excel files.
            if (!file.type.match("officedocument.*")) {
                continue;
            }
            ipcRenderer.send("file:dropped", {
                filepath: file.path,
            });
        }
        event.preventDefault();
        event.stopPropagation();
    },
};

filereader.init();

// 1) When the file reading is complete;
ipcRenderer.on("file:read-complete", (e, data) => {
    document.querySelector(".outer").innerHTML = data.data;
})

*/

/// All IPC events

ipcRenderer.on("program:error", (e, d) => {
    showSnackbar(d, "danger")
});

ipcRenderer.on("settings:updated", (e, data) => {
    showSnackbar(data.text, data.outcome)
    if (data.elemUpdated == "user") {
        Settings.users.createUsertable(Settings.systemSettings.users)
    } else if (data.elemUpdated == "intervals") {
        ipcRenderer.send("interval:updated");
    }
});

ipcRenderer.on("settings:once", function(e, Intervals) {
    Settings.intervals.createIntervalTable(Intervals)
});


ipcRenderer.on("login:status", function(e, status) {
    const portal = "." + status.portal + "status"
    $(portal).find("svg").each(function(idx, svg) {
        if ($(svg).hasClass(status.status)) {
            $(svg).removeClass("d-none")
        } else {
            $(svg).addClass("d-none")
        }
    });
    if (status.status == "green") {
        $(portal).attr("data-original-title", "Logged in")
            .tooltip('show');
    } else {
        $(portal).attr("data-original-title", "Not Logged in")
            .tooltip('show');
    }
})

ipcRenderer.on("db:editExisting", (event, data) => {
    showSnackbar("Recd Recall items for batch update in firestore", "info")
    return myfb.batchUpdate(data)
})

ipcRenderer.on("db:batchAdd", (e, data) => {
    showSnackbar("Recd fact items for Firestore batch add", "info")
    return myfb.batchAdd(data)
});

ipcRenderer.on("dbdata:stored", (ev, data) => {
    //inBuilt.get();
})

ipcRenderer.on("data:logs", (ev, Logs) => {
    logsHandler.set(Logs)
});

let NETWORK_DISABLED = false;

function isDeviceOnline() {
    return navigator.onLine;
}

function onlineOfflineDetection() {

    var isonline = isDeviceOnline();

    if (isonline) {
        console.log("Network is online")
        $(".deviceStatus .online").removeClass("d-none");
        $(".deviceStatus .offline").addClass("d-none");
        showSnackbar("Device is online!", "info");
        forOnlineFB()
    } else {
        console.log("Network is offline")
        $(".deviceStatus .online").addClass("d-none");
        $(".deviceStatus .offline").removeClass("d-none");
        showSnackbar("Device is offline!", "warning")
        forOfflineFB()
    };
}

function forOnlineFB() {
    if (true == NETWORK_DISABLED) {
        NETWORK_DISABLED = false;
        myfb.db.enableNetwork()
        myfb.changeLoginLinks(1);
        console.log("Network was Re-Enabled")
    }
}

function forOfflineFB() {
    NETWORK_DISABLED = true;
    myfb.signOut();
}

window.addEventListener("online", onlineOfflineDetection)
window.addEventListener("offline", onlineOfflineDetection)


var DateDiff = {

    addDays: function(D, d) {
        var result = d ? d : new Date();
        result.setDate(result.getDate() + D);
        return result;
    },

    inDays: function(d1, d2) {
        var t2 = d2.getTime();
        var t1 = d1.getTime();

        return Math.ceil((t2 - t1) / (24 * 3600 * 1000));
    },

    inWeeks: function(d1, d2) {
        var t2 = d2.getTime();
        var t1 = d1.getTime();

        return parseInt((t2 - t1) / (24 * 3600 * 1000 * 7));
    },

    inMonths: function(d1, d2) {
        var d1Y = d1.getFullYear();
        var d2Y = d2.getFullYear();
        var d1M = d1.getMonth();
        var d2M = d2.getMonth();

        return (d2M + 12 * d2Y) - (d1M + 12 * d1Y);
    },

    inYears: function(d1, d2) {
        return d2.getFullYear() - d1.getFullYear();
    }
}


var inBuilt = {

    get: function() {

        myfb.db.collection("disputes").get({ source: 'cache' }).then(query => {
            let data = query.docs.map(doc => {
                var x = doc.data();
                delete x.opus;
                x.FactItemAllocatedOn = new Date(1e3 * x.FactItemAllocatedOn.seconds + x.FactItemAllocatedOn.nanoseconds / 1e6)
                return x
            })
            inBuilt.set(data)
        });

    },
    showRem: async function() {
        var RI = $("div[aria-labelledby='notificationDropdown']").find(".notification-scroll");
        var RS = await this.utils.GR();
        RI.empty().append(this.utils.DR(RS));
        if (RS.length > 0) $(".rembadge").removeClass("d-none");
    },
    utils: {
        SR: async function(R) {

            return await AS.REM.put(R);
        },
        GR: async function() {
            var AR = await AS.REM.toArray();
            /*var T = new Date()
            AR = AR.map(I => {
                I.Due = DateDiff.inDays(T, I.Expiry);
                return I;
            }).sort((A, B) => {
                return A.Due - B.Due
            });*/

            return AR;
        },
        RR: async function(id, cd) {
            AS.transaction("rw", AS.REM, AS.CAPCH, async() => {
                await AS.REM.delete(id);
                await AS.CAPCH.where("CD").equals(cd).delete();
            }).then(() => {
                showSnackbar("Removed one notification!")
                return inBuilt.showRem();
            })

        },
        DR: function(R) {
            if (!R.length) {
                return [$("<div class='dropdown-item'>No Reminders</div>")]
            }
            var that = this;
            var ARS = R.map(I => {
                return that.RI(I);
            })
            return ARS;
        },
        SCD: async function(D) {
            var RD = await AS.CAPCH.where("CD").equals(D).toArray()
            RD = RD.map(I => { I.CD = new Date(I.CD).toLocaleDateString(); return I })
            var T = Settings.makeTable(RD);
            var EM = $("#emptyModal");
            EM.find("#emptyModalTitle").text("Capacity changes details");
            EM.find(".modal-body").empty().append($("<table class='table table-responsive'></table>").append(T));
            EM.modal("show");
        },
        RI: function(I) {
            //var BGC = I.Due == 0 ? "danger" : I.Due > 0 && I.Due <= 1 ? "warning" : "success"
            var AOS = I.R.match("Capacity") ? "<a href='javascript:void(0)' class='user-name' onclick='inBuilt.utils.SCD(" + I.ED + ")'>" + I.R + "</a>" : "<span class='user-name'>" + I.R + "</span>"
            var DI = $('<div class="dropdown-item" href="javascript:void(0)"></div>'),
                M = $('<div class="media"></div>'),
                MB = $('<div class="media-body"></div>'),
                NP = $(`<div class="notification-para">
                        ${AOS}
                        <span class=''>${new Date(I.ED).toUTCString()}</span>
                        </div>`),
                D = $(`<svg onclick="inBuilt.utils.RR(${I.id},${I.ED})" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#212529" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>`)
            M.append([MB.append(NP), D])
            DI.append(M)
            return DI
        },
    },
    counter: function(CD) {
        var TD = 0,
            TDV = 0,
            ODC = 0,
            ODV = 0,
            CDC = 0,
            CDV = 0
        CD.forEach((cd, idx) => {
            TD += cd.count_TotalDisputes;
            TDV += cd.sum_Balance;
            if (cd.Status == "Closed") {
                CDV = cd.sum_Balance;
                CDC = cd.count_TotalDisputes;
            } else {
                ODC += cd.count_TotalDisputes;
                ODV += cd.sum_Balance;
            }
        })

        const cSpeed = 3000;

        $(".ico-counter[data-display='TotalDisputes']").countTo({
            from: 0,
            to: TD,
            speed: cSpeed
        });

        $(".ico-counter[data-display='OpenDisputes']").countTo({
            from: 0,
            to: ODC,
            speed: cSpeed
        })
        ODV = ODV / 100000 // Divide by Million
        $(".ico-counter[data-display='OpenValue']").countTo({
            from: 0,
            to: ODV,
            speed: cSpeed,
            formatter: function(value, options) {
                return value.toFixed(2) + "K";
            }
        });
        $(".ico-counter[data-display='ClosedDisputes']").countTo({
            from: 0,
            to: CDC,
            speed: cSpeed
        });
        CDV = CDV > 0 ? CDV / 100000 : CDV // Divide by Million
        $(".ico-counter[data-display='ClosedValue']").countTo({
            from: 0,
            to: CDV,
            speed: cSpeed,
            formatter: function(value, options) {
                return value.toFixed(2) + "K";
            }
        });

    },
    data: [],
    set: function(inDBdata) {

        var self = this;

        function ND(X) {
            delete X.opus;
            try {
                X.FactItemAllocatedOn = new Date(1e3 * X.FactItemAllocatedOn.seconds + X.FactItemAllocatedOn.nanoseconds / 1e6)
            } catch (e) {
                console.log(X)
            }
            return X
        }

        if (this.data.length) {

            inDBdata.forEach(I => {
                if (I.type == "added") {
                    self.data.push(ND(I.doc))
                } else {
                    var IN = I.id
                    var OI = self.data.findIndex((E) => {
                        return E.InvoiceNo == IN
                    });
                    if (I.type == "modified") {
                        self.data[OI] = ND(I.doc)
                    } else if (I.type == "removed") {
                        self.data.splice(OI, 1);
                    }

                }
            })

        } else {
            this.data = inDBdata.map(I => {
                return ND(I.doc);
            });

        }

        // First for the counters;
        var counterData = SQLike.q({
            Select: ["|count|", "Status", "|as|", "TotalDisputes", "|sum|", "Balance", "|as|", "Balance", "Status"],
            From: this.data,
            GroupBy: ["Status"]
        })
        this.counter(counterData)
        return this.pivot();
    },
    wasPivoted: false,
    pivot: function() {
        if (this.wasPivoted) {
            webdatarocks.updateData({
                data: this.data
            });
        } else {
            var pivot = new WebDataRocks({
                container: "webdatapivot",
                toolbar: true,
                report: {
                    dataSource: {
                        data: this.data,
                        dataSourceType: "json"
                    },
                    slice: {
                        "reportFilters": [{
                            "uniqueName": "FactItemAllocatedOn",
                            "filter": {
                                "members": [
                                    "FactItemAllocatedOn." + new Date().toLocaleDateString()
                                ]
                            }
                        }],
                        "rows": [{ "uniqueName": "FactItemAllocatedTo" }],

                        "columns": [{ "uniqueName": "Status" }, { "uniqueName": "Bound" }],

                        "measures": [{
                            "uniqueName": "Status",
                            "aggregation": "count",
                            "availableAggregations": [
                                "count",
                                "distinctcount"
                            ]
                        }],
                        "expands": {
                            "columns": [{
                                "tuple": [
                                    "Status.Open"
                                ]
                            }]
                        }
                    }
                },
            });
            webdatarocks.refresh();
            this.wasPivoted = true;

        }

        var Q = SQLike.q({
            Select: ["Bound", "|count|", "Bound"],
            From: inBuilt.data,
            GroupBy: ["Bound"]
        });

        var C = Q.map(I => {
            return I.Bound
        })

        var D = Q.map(I => {
            return I.count_Bound
        })


        var sBar = {
            chart: {
                height: 350,
                type: 'bar',
                toolbar: {
                    show: false,
                }
            },
            plotOptions: {
                bar: {
                    horizontal: true,
                }
            },
            dataLabels: {
                enabled: false
            },
            series: [{
                data: D
            }],
            xaxis: {
                categories: C,
            }
        }

        var chart2 = new ApexCharts(
            document.querySelector(".bar-chart"),
            sBar
        );

        chart2.render();

        $(".time-updated").tooltip("Data updated on:" + new Date())
    }



}

var logsHandler = {
    colorIdx: function(i) {
        var colorpool = ["primary", "secondary", "success", "info", "warning", "dark"],
            l = colorpool.length
        return i > l ? colorpool[i % l] : colorpool[i]
    },
    newTimelineItem: function(Log, idx, LogOf) {

        var td = new Date(Log.timestamp)
        var ttime = td.getHours() + ":" + td.getMinutes();
        var tk = Log.ended ? parseInt((Log.ended - Log.timestamp) / 1000) : 0

        var item = $(`<div class="item-timeline"></div>`),
            tTime = $(`<p class="t-time">${ttime}</p>`),
            tdot = $(`<div class="t-dot t-dot-${Log.status == "Success" ? this.colorIdx(idx) : "danger"}" data-original-title="" title=""></div>`),
            ttext = $(`<div class="t-text"></div>`),
            tp = $(`<p>${Log.activity}</p>`)
        if (LogOf == "fact") {
            var tp1 = $(`<p class='t-meta-time'>New: ${Log.new}||Recall: ${Log.recalls}</p>`)
        } else if (LogOf == "main") {
            if (Log.activity.match("Modified")) {
                var tp1 = $(`<p class='t-meta-time'>Inv: ${Log.invoice}</p>`)
            } else if (Log.activity.match("Firestore")) {
                var tp1 = $(`<p class='t-meta-time'>Added: ${Log.added}|| Changes: ${Log.modified}</p>`)
            } else {
                var tp1 = $(`<p class='t-meta-time'>Removed: ${Log.removed}</p>`)
            }
        } else if (LogOf == "opus") {
            var tp1 = $(`<p class='t-meta-time'>No. of BL's: ${Log.totalBL}</p>`)
        }

        var tt = $(`<div class="badge badge-${Log.status.toLowerCase() == "success" ? "success" : "danger"}" data-err>${Log.status}</div>`)

        return item.append([tTime, tdot, ttext.append([tp, tp1, tt])]), item;
    },
    set: function(logdata) {
        var elemlog = $(`#${logdata.logsOf}-logs`).find(".timeline-line");
        elemlog.html("");
        var td;
        var l = logdata.logs.sort(function(a, b) { return b.timestamp - a.timestamp })
        l.forEach((log, ind) => {
            elemlog.append(this.newTimelineItem(log, ind, logdata.logsOf))
        });

        return;
    }
}


$(document).ready(function() {

    $(document).ajaxStop($.unblockUI);

    $("#registerModal").on("shown.bs.modal", function() {
        if (!isDeviceOnline()) {
            $(this).modal("hide");
            showSnackbar("Err: No internet connection", "info")
        }
    })

    $("#notificationDropdown").on("click", Ev => {
        Ev.preventDefault();
        if ($('body').hasClass('auth-false')) return;
        return inBuilt.showRem()
    });

    $(".createnewuser").on("click", function() {
        var modal = $("#userModal");
        modal.data("new", true)
        modal.find(".form-control").each((I, V) => {
            var DV = V.getAttribute("data-default");
            V.value = DV ? DV : ""
        })
        modal.modal("show")
    })

    $("#savecapacity").on("click", Settings.users.saveCapacity)

    $(".refresh-main").on("click", function() {
            ipcRenderer.send("checkdatafor:Firestore")
        })
        //Register
    $('#registerForm').on('submit', function(e) {
        e.preventDefault();
        return myfb.registerFormSubmit()
    });

    //$(".no-access").css({ "text-align", "center" })
    //Login
    $('#loginForm').on('submit', function(e) {
        e.preventDefault();
        return myfb.onLoginStateClicked();

    });

    $('#logout').on('click', function(e) {
        e.preventDefault();
        forOfflineFB();
        showSnackbar("Unsubscribed!!")
    });

    $("#showLoginModal").on("click", function(E) {
        if (isDeviceOnline()) {
            if (myfb.currentUser) {
                forOnlineFB();
            } else {
                $("#loginModal").modal("show")
            }
        } else {
            showSnackbar("Err: No internet connection", "info")
        }
    })

    $("#loginModal").on('shown.bs.modal', function() {
        $(this).find('#loginEmail').focus();
    });

    $(document).on("keydown", (event) => {
        if (event.key == "Escape") {
            if ($(".pvtFilterBox").is(":visible")) {
                $(".pvtFilterBox").hide();
            }
        }
    });

    $("#saveUserData").on("click", function() {
        return Settings.users.saveUser()
    })

    $(".editInterval").on("click", function() {
        var attr = $(this).attr("data-elem");
        var newinterval = $(this).parent().prev().find("input").val();
        Settings.intervals.updateInterval(attr, newinterval)
    })

    onlineOfflineDetection();

})

function openApp(app) {
    ipcRenderer.send("app:open", app)
}
const Datastore = require("nedb");
const path = require("path");
require("./sqlike.js")
var fs = require("fs")

if (!userDataPath) {
    var userDataPath = global.userDataPath ? window.userDataPath : "";
}

if (!userDataPath) {
    userDataPath = fs.readFileSync(path.resolve("UDP.txt"), 'utf-8')
}

const settingspath = path.resolve(__dirname, "settings.db");
//path.join(process.resourcesPath, "MainWindow", "assets", "js", "settings.db")
const resourcesPath = path.join(userDataPath, "Fire")

//const resourcesPath = process.env.NODE_ENV == "production" ? process.resourcesPath : __dirname.replace("assets/js", "")
// Initialize the Datastore and autoload it

exports.rpath = resourcesPath;

const sleep = async(ms) => {
    await new Promise(resolve => setTimeout(() => {
        resolve("hi")
    }, ms));
}
exports.mainDBHandler = {
    db: null,
    load: function() {
        if (!this.isloaded) {
            this.db = new Datastore({
                filename: path.join(resourcesPath, "offlinedisputes.db"),
                autoload: true,
            });
        }
        this.isloaded = true;
        return this;
    },
    manualDBLoad: function() {
        return this.db.loadDatabase();
    },
    insert: function(items) {
        return new Promise((resolve, reject) => {
            this.db.insert(items, (err, data) => {
                if (err) { return reject(err) }
                resolve(data)
            })
        })
    },
    isloaded: false,
    get: function(query, projection) {
        if (!projection) projection = {};
        if (!query) return this.getAllOnce(projection);
        return new Promise((resolve, reject) => {
            this.db.find(query, projection, (err, data) => {
                if (err) reject(err);
                resolve(data)
            })
        });
    },
    findOne: function(query) {
        return new Promise((resolve, reject) => {
            if (!query) reject("This function needs a query, got none")
            this.db.findOne(query, (err, data) => {
                if (err) reject(err);
                resolve(data)
            })
        });
    },
    findAndAdd: function(docToAdd) {
        return new Promise((resolve, reject) => {
            this.db.findOne({ id: docToAdd.id }, function(err, doc) {
                if (err) {
                    reject(err);
                }
                if (!doc) {
                    this.db.insert(docToAdd);
                    resolve(1);
                } else {
                    resolve(0);
                }
            });
        });
    },
    getAllOnce: function(Projection) {

        return new Promise((resolve, reject) => {
            this.db.find({}, Projection, function(err, data) {
                if (err) {
                    reject(err);
                }
                resolve(data);
            });
        });
    },
    countAll: function() {
        return new Promise((res, rej) => {
            this.db.count({}, function(err, count) {
                if (err) {
                    rej(err);
                }
                res(count);
            });
        });
    },
    modify: function(id, modifiedDoc) {
        var that = this;
        return new Promise((resolve, reject) => {
            this.db.update({ _id: id }, modifiedDoc, {},
                (err, success) => {
                    if (err) {
                        reject(err);
                    }
                    that.db.persistence.compactDatafile()
                    resolve(success);
                }
            );
        });
    },
    countOpen: function() {
        return new Promise((res, rej) => {
            this.db.count({ Status: "Open" }, function(err, count) {
                if (err) {
                    rej(err);
                }
                res(count);
            });
        });
    },
    aggregate: function() {

        var projection = {
            Status: 1,
            Bound: 1,
            ParentName: 1,
            Region: 1,
            FactItemAllocatedOn: 1,
            Collector: 1,
            DisputeResolvedOn: 1,
            Balance: 1,
            OpenStatus: 1,
            DueDate: 1,
            InvoiceNo: 1,
            FactItemAllocatedTo: 1,
        }

        return new Promise((resolve, reject) => {
            this.db.find({}, projection, function(err, data) {
                if (err) reject(err);

                function office() {
                    return this.InvoiceNo.substr(0, 5)
                }

                const now = new Date().getTime();

                function daysToResolve() {
                    try {
                        return this.Status == "Open" ?
                            parseInt((now - new Date(this.FactItemAllocatedOn).getTime()) / (24 * 3600 * 1000)) :
                            parseInt((new Date(this.DisputeResolvedOn).getTime() - new Date(this.FactItemAllocatedOn).getTime()) / (24 * 3600 * 1000))
                    } catch (e) {
                        console.log(e.message)
                        return 0
                    }
                }
                /*
                let group1 = SQLike.q({
                    Select: ["Status", "Bound", "ParentName", "Region", "FactItemAllocatedTo", "Collector", office, "|as|", "Office", "|count|", "Status", "|as|", "Count", "|sum|", "Balance", "|as|", "Sum"],
                    From: data,
                    GroupBy: ["Status", "Bound", "Region", "FactItemAllocatedTo", "Collector", "Office"],
                });

                let group3 = SQLike.q({
                    Select: ["FactItemAllocatedOn", "Status", "ParentName", "|sum|", "Balance", "|as|", "Sum", daysToResolve, "|as|", "DaysToResolve"],
                    From: data,
                    GroupBy: ["FactItemAllocatedOn", "Status", "ParentName"],
                    OrderBy: ["sum_Sum", "|desc|", "Aging", "|desc|"],
                })

                let group2 = SQLike.q({
                    Select: [daysToResolve, "|as|", "DaysToResolve", "FactItemAllocatedOn", "Status"],
                    From: data,
                    GroupBy: ["FactItemAllocatedOn", "Status"]
                });
                */
                function aging() {
                    return this.Status == "Open" ?
                        parseInt((new Date(this.FactItemAllocatedOn).getTime() - new Date(this.DueDate).getTime()) / (24 * 3600 * 1000)) :
                        parseInt((new Date(this.DisputeResolvedOn).getTime() - new Date(this.DueDate).getTime()) / (24 * 3600 * 1000))
                }

                data.forEach(function(v, i) {
                    v.Aging = aging.bind(v)();
                    v.DaysToResolve = daysToResolve.bind(v)();
                    v.Office = office.bind(v)();
                })

                resolve(data);
            });
        })
    },
    findWhere: function(findval) {
        return new Promise((resolve, reject) => {
            this.db.find({
                    $where: function() {
                        return findval.indexOf(this.InvoiceNo) != -1;
                    },
                },
                (err, docs) => {
                    if (err) reject(err);
                    resolve(docs);
                }
            );
        })
    },
    remove: function(invoiceNo) {
        var that = this;
        return this.db.remove({ _id: invoiceNo }, { multi: false }, function(e, n) {
            that.db.persistence.compactDatafile();
        })
    },
    test: function() {
        var that = this;
        this.get().then(Snapshots => {
            Snapshots.forEach((Snap, I) => {
                Snap = formatted(Snap);
                that.modify(Snap.InvoiceNo, Snap).then(modified => {
                    console.log(modified)
                }).catch(e => {
                    console.log(e)
                })
            });
        })
    }
};

exports.credentials = {
    load: function() {
        this.db = new Datastore({
            filename: path.join(resourcesPath, "cred.db"),
            autoload: true,
        });
        this.isloaded = true;
        return this;
    }
}


exports.fact = {

    load: function() {
        if (!this.isloaded) {
            this.db = new Datastore({
                filename: path.join(resourcesPath, "fact.db"),
                autoload: true,
            });
        }
        this.isloaded = true
        return this;
    },
    manualDBLoad: function() {
        return this.db.loadDatabase();
    },
    db: null,
    isloaded: false,
    get: function(query) {
        if (!query) query = {};
        return new Promise((resolve, reject) => {
            this.db.find(query, (err, data) => {
                if (err) reject(err);
                resolve(data)
            })
        })
    },
    insert: function(items) {
        return new Promise((resolve, reject) => {
            this.db.insert(items, (err, data) => {
                if (err) { reject(err) }
                resolve(data)
            })
        })
    },
    update: function(keyToUpdate, updateData) {
        var that = this;
        return new Promise((resolve, reject) => {
            this.db.update(keyToUpdate, updateData, { multi: false }, (err, data) => {
                if (err) return reject(err);
                resolve(data)
            })
        })
    },
    compact: function() {
        return this.db.persistence.compactDatafile();
    },
    delete: function(itemsToDelete) {
        var that = this;
        return new Promise((resolve, reject) => {
            let removed = 0;
            let errorOnRemoved = 0;
            const toRemove = itemsToDelete.length
            for (var z = 0; z < toRemove; z++) {
                var itemToRemove = itemsToDelete[z].InvoiceNo
                this.db.remove({ InvoiceNo: itemToRemove }, { multi: false }, function(err, numRemoved) {
                    if (err) { errorOnRemoved += 1 }
                    removed += numRemoved;
                    if (removed + errorOnRemoved == toRemove) {
                        that.db.persistence.compactDatafile();
                        resolve({ toRemove: toRemove, removed: removed })
                    }
                })
            }

        })
    }
}

exports.logs = function(dbname) {

    this.load = function(db) {
            if (this.isloaded && db == this.dbname) return this;
            this.active = new Datastore({
                filename: path.join(resourcesPath, db + "log.db"),
                autoload: true,
            });
            this.isloaded = true
            this.dbname = db;
            return this;
        },
        this.manualDBLoad = function() {
            return this.active.loadDatabase();
        },
        this.active = null
    this.dbname = ""
    this.isloaded = false
    this.insert = function(logitem) {
        return new Promise((resolve, reject) => {
            this.active.insert(logitem, (e, added) => {
                if (e) reject(e)
                resolve(1);
            })
        })
    }
    this.read = function(query, projection) {
        if (!projection) projection = {};
        if (!query) query = {}
        return new Promise((resolve, reject) => {
            this.active.find(query, projection, (err, data) => {
                if (err) reject(err)
                resolve(data)
            })
        })
    }

    this.init = function(dbname) {
        return this.load(dbname)
    }

    this.compact = function() {
        return this.active.persistence.compactDatafile();
    }

    this.init(dbname);
}



exports.settings = {
    load: function(force) {
        if (this.isloaded) {
            if (!force) return this;
        }
        this.db = new Datastore({
            filename: settingspath,
            autoload: true,
        });
        this.isloaded = true;
        return this;
    },
    isloaded: false,
    get: function(what) {
        if (!what) what = {}
        return new Promise((resolve, reject) => {
            this.db.find(what, function(e, d) {
                if (e) return reject(e);
                resolve(d);
            });
        });
    },
    update: function(keyToUpdate, updateData) {
        return new Promise((resolve, reject) => {
            this.db.update(keyToUpdate, updateData, { multi: false }, function(err, cnt) {
                if (err) reject(err);
                resolve(1);
            })
        })
    },
    close: function() {
        this.isloaded = false;
    }
};









/*
data = []
function getdata(){
    fs.readFile("convertcsv.json", "utf-8", (err, d)=>{
        data = JSON.parse(d)
    })
}
getdata()

function newd(old){
    const x = old.split("/")
    return x[1] + "/" + x[0] + "/" + x[2]
}

for(var len = data.length, z =0; z < len;z++){
    try{
        data[z].FileDate = new Date(newd(data[z].FileDate))
    } catch(e) {};
    try{
        data[z].DueDate = new Date(newd(data[z].DueDate))
    } catch(e) {};
    try{
        data[z].SLD = new Date(newd(data[z].SLD))
    } catch(e) {};
    data[z].Paid = Number(data[z].Paid)
}



/*
const PouchDB = require("pouchdb");

const db = new PouchDB(path.join(__dirname, "mydb"));

exports.pouch = {
    
    update: function(id, objToUpdate){
        
    },
    getById: function(id){
        return db.getById(id)
    },
    getAll: function(){
        return db.getAll([])
    },
    getLast: function(){
        
    },
    
    
    
}


doc = {
    _id: new Date().toISOString(),
    name: "HJ",
    age: 23,
    occupation: "coder",
};

db.put(doc)
.then((res) => {
    console.log("Document inserted OK");
})
.catch((err) => {
    console.error(err);
});

db.allDocs({ include_docs: true, descending: true }, function(err, doc) {
    console.log( JSON.stringify(doc.rows))
})

*/
// Add Comment key top Firestore
// Keep existing comments, add new comments to existing
// Add Parent Code to Fact line

const path = require("path");

const { ipcRenderer } = require("electron");

const resourcesPath = process.env.NODE_ENV == "production" ? process.resourcesPath : __dirname.replace("html", "")

const Dexie = require(path.join(resourcesPath, "assets", "js", "dexie.js"));

// Userdata path, the hard way
ipcRenderer.send("get:UDP", "fact");

let logs, db, userDataPath, settings, FACT_INTERVAL = 5

function getSettings() {
    db.settings.load();
    db.settings.get({ item: "systemSettings" }).then(Settings => {
        settings = Settings[0].data;
        FACT_INTERVAL = Number(settings.intervals.fact)
        console.log("Got settings")
    })
}

ipcRenderer.on("UDP", (E, D) => {
    window.userDataPath = D
    db = require(path.join(resourcesPath, "assets", "js", "offlinedb.js"))
    logs = new db.logs("fact");
    getSettings();
});

const webview = document.querySelector('webview')

const showloader = () => {
    document.querySelector(".lds-spinner").style.visibility = "visible"
}

const hideloader = () => {
    document.querySelector(".lds-spinner").style.visibility = "hidden"
}

const isloaderHidden = () => {
    return document.querySelector('.lds-spinner').style.visibility == 'hidden' ? true : false
}

const sleep = async(ms) => {
    await new Promise(resolve => setTimeout(() => {
        resolve("hi")
    }, ms));
}

let lastLoadedURL;

let theInterval;

let SIGNAL_TO_WAIT = false;

function clearSchedule() {
    clearInterval(theInterval);
    console.log("Interval cleared. Please re-load the page to restart the interval")
    return;
}

const B = new Dexie("Basic");

B.version(1).stores({ creds: "App,Id,Pwd" });

onload = () => {

    const {
        ipcRenderer
    } = require("electron")

    ipcRenderer.on("signal:Wait", (e, signalToWait) => {
        SIGNAL_TO_WAIT = signalToWait
    });

    ipcRenderer.on("new:interval", function(event, newInterval) {
        FACT_INTERVAL = newInterval;
        clearSchedule();
        setSchedule();
    })

    const indicator = document.querySelector('.indicator')

    //webview.addEventListener("did-start-loading", showloader);

    webview.addEventListener("did-finish-load", function() {
        hideloader();
        const PageResults = `function a(){
                    return {
                    hasLoginForm: document.querySelectorAll("#Username").length,
                    title: document.title,
                    cssMenu: document.querySelectorAll(".pureCssMenu").length,
                    h1: (document.querySelector("h1") ? document.querySelector("h1").innerText : ""),
                    activeTab: document.querySelector(".ui-state-active") ?document.querySelector(".ui-state-active").innerText : "",
                    href: document.location.href,
                    searchFormElement: document.querySelectorAll("#main_content_AssignedToGroup").length
                }}; a();`;

        webview
            .getWebContents()
            .executeJavaScript(PageResults)
            .then(pageResults => {
                lastLoadedURL = pageResults.href;
                if (pageResults.href == "about:blank") {
                    return navigateToFact();
                }
                if (pageResults.hasLoginForm) {
                    ipcRenderer.send("login:status", {
                        portal: "fact",
                        status: "red"
                    })
                    return doLogin();
                } else if (pageResults.cssMenu && !pageResults.searchFormElement) {
                    ipcRenderer.send("login:status", {
                        portal: "fact",
                        status: "green"
                    })
                    return loadInvoiceListing();
                } else if (pageResults.cssMenu && pageResults.title == "FACT Invoice Listing") {
                    if (pageResults.activeTab == "Results") {
                        return doDataExport()
                    } else {
                        if (!theInterval) setSchedule();
                        return getData()
                    }
                }
            })
            .catch(err => {
                console.log(err)
            })
    })

    function setSchedule() {
        const secs = parseInt(FACT_INTERVAL) * 60 // Convert to Seconds
        theInterval = setInterval(getData, secs * 1000);
        console.log("Running at an interval of every " + secs + " seconds..!")
        return theInterval
    }

    function doLogin() {
        B.creds.get({ App: "Fact" }).then(cred => {
            if (!cred) return provideCreds();
            const code = `
                document.querySelector("#Username").value = '${cred.Id}'
                document.querySelector("#Userpass").value = '${cred.Pwd}'
                    `
            webview.getWebContents().executeJavaScript(code)
                .then(data => {
                    return;
                });
        })
    }

    function provideCreds() {
        var RP = path.join(resourcesPath, "LoginToFact.html"),
            DTG = path.join(resourcesPath, "SetCredentials.html#fact")
        document.location.href = DTG + `?App=Fact;ComingFrom=Fact;RP=${RP};Al=true`
    }


    function navigateToFact() {
        showloader();
        return webview
            .getWebContents()
            .executeJavaScript(`document.location.href = "https://fact.one-line.com"`)
            .then(s => {
                console.log(s)
            })
            .catch(err => {
                console.log(err)
            })
    }

    function loadInvoiceListing(err) {
        if (err) console.log(err)
        console.log("Came to click invoice anchor")
        showloader();
        const code = `document.querySelector("a[href='InvoiceListing.aspx']").click();`
        webview.getWebContents().executeJavaScript(code)
            .then(data => {
                console.log(data)
            });
    }

    function setTransactionState(state) {
        //FLAG_TRANSACTION_IN_PROGRESS = state
        ipcRenderer.send("signal:WaitForFACT", state)
    }

    function getData() {

        // Return if main asks to wait
        if (SIGNAL_TO_WAIT) {
            console.log("Have recd a Wait signal from the Main Process!")
            return;
        } else {
            setTransactionState(true)
        }
        console.log("Came to get data")
        showloader();
        const code = `document.querySelector("#main_content_AssignedToGroup").value = "Reconciliation";
                document.querySelector("#main_content_SearchBtn").click();
            `
        webview.getWebContents().executeJavaScript(code)
            .then(data => {
                showloader()
            }).catch(err => {
                setTransactionState(false)
            })
    }

    function doDataExport() {
        setTransactionState(true);
        console.log("Doing data export")
        showloader();
        const timestamp = new Date().getTime();
        const code = `
                    window
                    .jQuery
                    .get("https://fact.one-line.com/InvoiceListingCSV.ashx", function(data){
                      return data;
                    })
                `
        webview.getWebContents().executeJavaScript(code)
            .then(data => {
                hideloader();
                data = CSVToJSON(data);
                if (typeof data == "string") data = JSON.parse(data)
                if (!data.length) return;
                if (Object.keys(data[data.length - 1]).length < 10) {
                    data.pop();
                }
                return ManageFactData(data)
            }).catch(err => {
                setTransactionState(false);
                ipcRenderer.send("fact:data", {
                    error: err,
                    timestamp: timestamp
                });
            })
    }


    function ManageFactData(FactData) {

        // Pre check.. If no data, simply return
        if (!FactData) return;


        // Pre Check sometimes Fact data stays back even after posting in Firestore
        // We will try to delete them if found;
        async function marryFACTandMain() {
            db.mainDBHandler.load();
            db.fact.load();
            const fd = await fact.get().then(data => { return data });
            const md = await main.get().then(data => { return data });
            const fdInv = fd.map((fdi, id) => {
                return fdi.InvoiceNo
            });
            const mdInv = md.map((mdi, id) => {
                return mdi.InvoiceNo
            });
            let matchedChildren = [];
            fdInv.forEach((fdi, id) => {
                if (mdInv.indexOf(fdi) != -1) {
                    matchedChildren.push({ InvoiceNo: fdi })
                }
            })
            if (matchedChildren) {
                await db.fact.delete(matchedChildren);
                console.log("Deleted Matching Invoice Nos:" + matchedChildren.length)
            }
        }




        // Remove the keys which we don;t need
        function removeUnwatedKeys(FD) {

            return new Promise((resolve, reject) => {

                const sysSettings = settings;
                const fileHeaders = sysSettings.fileHeaders;
                const addlHeaders = sysSettings.additionalNewHeaders;

                function newSingleObj(headers, addlHeaders) {
                    const retObj = {},
                        addlObj = {};
                    for (var z = 0; z < headers.length; z++) {
                        retObj[headers[z].field] = headers[z].default;
                    }
                    for (z = 0; z < addlHeaders.length; z++) {
                        addlObj[addlHeaders[z].field] = addlHeaders[z].default;
                    }
                    return [retObj, addlObj];
                }

                const [FH, AH] = newSingleObj(fileHeaders, addlHeaders);
                const ObjKeys = Object.keys(FH);
                const len = FD.length;
                const out = [];
                var GH;
                for (var z = 0; z < len; z++) {
                    GH = {};
                    ObjKeys.forEach(function(key, idx) {
                        GH[key] = FD[z][key];
                    });
                    out.push(Object.assign(GH, AH));
                }
                resolve(out);
            })

        }

        // Then get all items from existing fact log
        function getRidOfExisingFactItemsInFactLog(NewFromFact) {
            const newFactItemCount = NewFromFact.length;

            return new Promise((resolve, reject) => {
                db.fact.load().get({}).then(factdata => {
                    factdata.forEach((factItem, factIndex) => {
                        for (var x = 0; x < NewFromFact.length; x++) {
                            if (NewFromFact[x].InvoiceNo == factItem.InvoiceNo) {
                                NewFromFact.splice(x, 1);
                                break;
                            }
                        }
                    })
                    console.log(newFactItemCount - NewFromFact.length + " items were removed during Fact to FactDB match");
                    resolve(NewFromFact)
                }).catch(err => {
                    reject(err)
                })
            })
        }

        // Then match the remaining items with the items in the main database
        function matchWithAllFacts(FromFact) {

            let fflen = FromFact.length;
            // Now from our DB match and get all the items where these invoice numbers match
            // and return a promise
            return new Promise((resolve, reject) => {

                    // Get all Invoice numbers to match from the newly recd fact data
                    const invno = FromFact.map((item, idx) => {
                        return item.InvoiceNo
                    });
                    // Failsafe
                    if (!invno) invno = [];
                    // Items which exist needn't be added again
                    let ReCalls = 0;
                    // Find items matching newly recd invoicenumbers
                    db.mainDBHandler.load();

                    db.mainDBHandler.findWhere(invno).then(found => {

                        found.forEach((line, idx) => {
                            for (var z = 0; z < FromFact.length; z++) {
                                if (FromFact[z].InvoiceNo == line.InvoiceNo) {
                                    if (FromFact[z].Status == "Open" && line.Status == "Closed") {
                                        const ReOpenedTimes = line.hasOwnProperty("ReOpenedTimes") ? line.ReOpenedTimes++ : 1;
                                        FromFact[z].ReOpened = ReOpenedTimes
                                        FromFact[z].isAnUpdate = true
                                        FromFact[z].Comment = line.Comment + "\n" + FromFact[z].Comment
                                        ReCalls++
                                        break;
                                    } else {
                                        FromFact.splice(z, 1);
                                        z = z - 1;
                                        break;
                                    }
                                }
                            }
                        });
                        console.log(fflen - FromFact.length + " items removed from MainDB to Fact match. " + ReCalls + " items were recalls!")
                        resolve({ FromFact: FromFact, ReCalls: ReCalls })

                    }).catch(err => {
                        reject(err)
                    })

                }) // Return promise

        }

        async function pushToFact(FinalDataForFact) {
            return new Promise((resolve, reject) => {
                db.fact.insert(FinalDataForFact).then(
                    (dataInserted) => {
                        resolve(dataInserted)
                    }
                ).catch((err) => {
                    reject(err)
                })
            })
        }

        const timestamp = new Date().getTime();

        console.log("Actual Items received from Fact :" + FactData.length)

        removeUnwatedKeys(FactData).then(FactData => {
            //console.log("removed unwanted keys..")
            getRidOfExisingFactItemsInFactLog(FactData)
                .then((ExistingRemoved) => {
                    //console.log("Got rid of existing items from fact");
                    matchWithAllFacts(ExistingRemoved)
                        .then(unique => {
                            var UniqueData = unique.FromFact,
                                Recalls = unique.ReCalls
                                //console.log("Got Unique items");
                                // Changing this as this makes it dependent
                                // Send Updates directly to main
                                /*if (UniqueData.Updates.length) {
                                    ipcRenderer.send("db:editExisting", {
                                        updates: UniqueData.Updates,
                                    });
                                }*/
                                // Requesting only a subset for testing purposes
                                //UniqueData = UniqueData.splice(0, 50)
                            console.log(`Total of ${UniqueData.length} were received from FACT tool`)

                            pushToFact(UniqueData)
                                .then(() => {
                                    console.log("Pushed data to fact log");
                                    logs.insert({
                                        timestamp: timestamp,
                                        activity: "Fact data download",
                                        status: "Success",
                                        new: UniqueData.length,
                                        recalls: Recalls,
                                        ended: new Date().getTime(),
                                        err: {},
                                    });
                                    console.log("Deprecated: Telling Opus to Fetch data..")
                                    setTransactionState(false);
                                    //ipcRenderer.send("tell:opusToFetch", 1)

                                    webview
                                        .getWebContents()
                                        .executeJavaScript(
                                            `document.querySelector("a[href='#tabs-1']").click();`
                                        )
                                        .then(() => {
                                            console.log(
                                                "Data Saved to disk and tab selection updated"
                                            );
                                        })
                                        .catch((er) => console.log(er));

                                })
                                .catch((err) => {
                                    logs.insert({
                                        timestamp: timestamp,
                                        status: "Fail",
                                        activity: "Fact data download",
                                        error: {
                                            message: err.message,
                                            stack: err.stack,
                                        },
                                        ended: new Date().getTime(),
                                    });
                                    setTransactionState(false);
                                });
                        })
                        .catch((err) => {
                            logs.insert({
                                timestamp: timestamp,
                                status: "Fail",
                                activity: "Fact data download",
                                error: {
                                    message: err.message,
                                    stack: err.stack,
                                },
                                ended: new Date().getTime()
                            });
                            setTransactionState(false);
                        });
                })
                .catch((err) => {
                    logs.insert({
                        timestamp: timestamp,
                        status: "Fail",
                        activity: "Fact data download",
                        ended: new Date().getTime(),
                        error: {
                            message: err.message,
                            stack: err.stack,
                        },
                    });
                    setTransactionState(false);
                });

        }).catch(err => {
            logs.insert({
                timestamp: timestamp,
                status: "Fail",
                activity: "Fact data download",
                ended: new Date().getTime(),
                error: {
                    message: err.message,
                    stack: err.stack,
                },
            });
            setTransactionState(false);
        });
    }

    function CSVToArray(csvData, delimiter) {
        delimiter = (delimiter || ",");
        var pattern = new RegExp((
            "(\\" + delimiter + "|\\r?\\n|\\r|^)" +
            "(?:\"([^\"]*(?:\"\"[^\"]*)*)\"|" +
            "([^\"\\" + delimiter + "\\r\\n]*))"), "gi");
        var data = [
            []
        ];
        var matches = null;

        while (matches = pattern.exec(csvData)) {
            var matchedDelimiter = matches[1];
            if (matchedDelimiter.length && (matchedDelimiter != delimiter)) {
                data.push([]);
            }
            if (matches[2]) {
                var matchedDelimiter = matches[2].replace(
                    new RegExp("\"\"", "g"), "\"");
            } else {
                var matchedDelimiter = matches[3];
            }
            data[data.length - 1].push(matchedDelimiter);
        }
        return (data);
    }

    function renameSimilarColumns(colname, colArray) {
        var simCounter = 0
        colArray.forEach((arrItem, arrIndex) => {
            arrItem = typeof arrItem == "string" ? arrItem.trim() : arrItem
            if (arrItem == colname) {
                if (simCounter > 0) {
                    colArray[arrIndex] = arrItem + "_" + simCounter
                }
                simCounter++
            }
        })
        return colArray
    }

    function CSVToJSON(csvData) {
        var data = CSVToArray(csvData);
        data[0] = renameSimilarColumns("Bound", data[0])
        var objData = [];
        for (var i = 1; i < data.length; i++) {
            objData[i - 1] = {};
            for (var k = 0; k < data[0].length && k < data[i].length; k++) {
                var key = data[0][k].trim();
                objData[i - 1][key] = typeof data[i][k] == "string" ? data[i][k].trim() : data[i][k]
            }
        }
        var jsonData = JSON.stringify(objData);
        jsonData = jsonData.replace(/},/g, "},\r\n");
        return jsonData;
    }

    setTimeout(() => {
        if (!isloaderHidden()) {
            const setlocationToBlank = `document.location.href="about:blank"`
            webview.getWebContents().executeJavaScript(setlocationToBlank).then(() => {
                console.log("Force location setting to blank");
            })
        }
    }, 5000)



}
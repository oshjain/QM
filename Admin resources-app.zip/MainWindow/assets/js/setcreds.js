let B = new Dexie("Basic")
B.version(1).stores({ creds: "App,Id,Pwd" })

$(document).ready(function() {

    var loc = window.location.href.split("?");
    loc.splice(0, 1);
    loc = loc[0].split(";")
    var app = loc[0].split("=")[1];
    var from = loc[1].split("=")[1];
    var rp = loc[2].split("=")[1];
    var al = loc[3].split("=")[1];

    $(".registerforapp").text(app);
    $("#App").val(app);

    if (from) {
        var r = app ? app : from
        $(".gobackto").attr("route", r).show().text("Go back to " + (r == "Main" ? "Dashboard" : r))
    }

    $(".gobackto").on("click", function(E) {
        var gobackto = $(this).attr("route");
        if (app == "Opus") {
            window.location.replace("OpusLogin.html")
        } else if (app == "Fact") {
            window.location.replace("LoginToFact.html")
        } else if (from == "Main") {
            window.location.replace("mainPage.html");
        }
    });

    $("#toggle-password").on('click', function() {
        var x = document.getElementById("Pwd");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    });

    $("#App").on("change", function(E) {
        $(".registerforapp").text($(this).val());
    })

    if (al) {
        alert(`Your credentials for ${app} were either not found or have expired. To continue enjoying automated login, kindly set your credentials for ${app} here`);
    }

    $(".submit").on("click", function(E) {
        E.preventDefault();
        if (!Id.value) return alert("ID is required");
        if (!Pwd.value) return alert("Password is required");
        if (!App.value) return alert("Please select the app")
        B.creds.put({ App: App.value, Id: Id.value, Pwd: Pwd.value }).then(() => {
            alert("Credentials Successfully set for " + App.value + "!");
            document.getElementsByTagName("form")[0].reset();
        }).catch(E => {
            alert("Error while setting credentials. Please contact the developer!\n\nError:" + E.message);
        });
    });


});
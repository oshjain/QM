var gapicred = require(require("path").resolve("./MainWindow/credentials.json"));

var CLIENT_ID = gapicred.web.client_id;
var API_KEY = gapicred.api_key

// Array of API discovery doc URLs for APIs used by the quickstart
var DISCOVERY_DOCS = ["https://www.googleapis.com/discovery/v1/apis/drive/v3/rest"];

// Authorization scopes required by the API; multiple scopes can be
// included, separated by spaces.
var SCOPES = 'https://www.googleapis.com/auth/drive.metadata.readonly ';
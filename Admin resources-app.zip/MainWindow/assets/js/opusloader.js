const resourcesPath =
    process.env.NODE_ENV == 'production' ?
    process.resourcesPath :
    __dirname.replace('html', '')

const path = require('path')

const { ipcRenderer } = require('electron')

const Dexie = require(path.join(resourcesPath, "assets", "js", "dexie.js"));

// Userdata path, the hard way
ipcRenderer.send("get:UDP", "opus");

const B = new Dexie("Basic");

B.version(1).stores({ creds: "App,Id,Pwd" });

let fact, logs, settings
let FLAG_TRANSACTION_IN_PROGRESS = false;
let SIGNAL_TO_WAIT = false;
let OPUS_INTERVAL = 5 // Default
let theInterval;
let Logs;
let opusFieldMap;

const showloader = () => {
    document.querySelector('.lds-spinner').style.visibility = 'visible'
}
const hideloader = () => {
    document.querySelector('.lds-spinner').style.visibility = 'hidden'
}
const isloaderHidden = () => {
    return document.querySelector('.lds-spinner').style.visibility == 'hidden' ? true : false
}

const webview = document.querySelector('webview')

ipcRenderer.on("UDP", (E, D) => {
    window.userDataPath = D
    db = require(path.join(resourcesPath, "assets", "js", "offlinedb.js"))
    fact = db.fact;
    logs = db.logs;
    settings = db.settings;
    Logs = new logs("opus")
    getOpusFields();
});



const cdataReplaceRegEx = str => {
    return str.replace(/\]?]>/g, ']').replace(/<!\[CDATA/g, '')
}

const requestor = {
    get: function(bl, tt, bo, office) {
        const TT = this[tt]
        return {
            url: TT.url,
            params: TT.hasOwnProperty('getParams') ?
                TT.getParams(bl, office) : TT.params + bl,
            bound: TT.bound.indexOf(bo.toLowerCase())
        }
    },
    booking: {
        url: 'https://cntr.one-line.com/opuscntr/ESM_BKG_0079_01GS.do',
        params: 'f_cmd=2&bkg_no=&bl_no=',
        bound: ['export', 'import']
    },
    internalRemarks: {
        url: 'https://cntr.one-line.com/opuscntr/ESD_TRS_0982GS.do',
        params: 'f_cmd=2&eq_no=&usr_id=WMLHASJ1&inter_rmk_cd=B&readFlg=N&bk_no=',
        bound: ['export', 'import']
    },
    charges: {
        url: 'https://cntr.one-line.com/opuscntr/ESM_BKG_0079_08GS.do',
        params: 'f_cmd=2&pagerows=&bkg_no=&bl_no={BLNO}&application_date=&frm_t10sheet1_rmark_yn=&frm_t10sheet1_rfa_yn=&sc_no=&caflag=&autoRate=N&removeAll=N&bdrflag=&rOfc_cd=&sc_available=&rfa_available=&taa_available=&frm_t10sheet1_bkg_sts_cd=&frm_t10sheet1_bkg_rt_whf_expt_cd=&frm_t10sheet1_bkg_svc_scp_cd=&flex_hgt_flg=&frm_rcv_term_cd=YDSTIMydstim&frm_de_term_cd=YDSTOMydstom&modify_flag=N&frm_t10sheet1_hngr_flg=&frm_t10sheet1_rc_flg=&frm_t10sheet1_rt_bl_tp_cd_old=&isInquiry=Y&isOrgInquiry=Y&page_type=ESM_BKG_0079_08&oblIssFlg=N&frm_t10sheet1_rt_aply_dt_bak=&multi_cgo=&frm_t10sheet1_doc_loc_cd=&to_be_ppd_cust_cd=&to_be_clt_cust_cd=&frm_p_t10sheet3_cust_seq_hs=&frm_p_t10sheet3_cust_seq_rsn=&frm_c_t10sheet3_cust_seq_hs=&frm_c_t10sheet3_cust_seq_rsn=&lst_sav_dt=&frm_t10sheet1_bkg_no=&frm_t10sheet1_rt_aply_dt=&frm_t10sheet1_aud_sts_cd=&rt_bl_tp_cd_text=&rt_bl_tp_cd=&frm_t10sheet1_rt_bl_tp_cd=&covered_name_m=&covered_name_c=&frm_t10sheet1_mst_cvrd_bl=&inrAuth1=COBIZ&inrAuth2=&inrAuth3=&inrAuth4=INR%2F&inrAuth5=&inrAuth6=&frm_t10sheet1_cobiz_auth_no=&frt_term_cd_text=&frt_term_cd=&frm_t10sheet1_frt_term_cd=&frm_t10sheet1_por_cd=&frm_t10sheet1_pol_cd=&frm_t10sheet1_pod_cd=&frm_t10sheet1_del_cd=&frm_t10sheet1_pre_rly_port_cd=&frm_t10sheet1_pst_rly_port_cd=&frm_t10sheet1_act_wgt=&frm_t10sheet1_wgt_ut_cd=&frm_t10sheet1_meas_qty=&frm_t10sheet1_meas_ut_cd=&frm_t10sheet1_special=&frm_t10sheet1_rcv_term_cd=&frm_t10sheet1_de_term_cd=&svc_scp_cd=&frm_t10sheet1_svc_scp_cd=&frm_t10sheet1_cstms_desc=&frm_t10sheet1_rep_cmdt_cd=&frm_t10sheet1_rep_cmdt_nm=&frm_t10sheet1_cmdt_cd=&frm_t10sheet1_cmdt_nm=&frm_t10sheet1_sc_no1=&frm_t10sheet1_sc_amd_seq=&frm_t10sheet1_sc_no2=&frm_t10sheet1_brk_dwn_flg=&frm_t10sheet1_rfa_no=&frm_t10sheet1_rfa_amd_seq=&frm_t10sheet1_taa_no=&frm_t10sheet1_taa_amd_seq=&frm_t10sheet1_decl_cgo_chg_amt=&frm_t10sheet1_decl_cgo_curr_cd=&ibTabTop0=&editpage0=&ibTabBottom0=&ibTabTop1=&editpage1=&ibTabBottom1=&ibTabTop2=&editpage2=&ibTabBottom2=&ibTabTop3=&editpage3=&ibTabBottom3=&ibTabTop4=&editpage4=&ibTabBottom4=&ibTabTop5=&editpage5=&ibTabBottom5=&ibTabTop6=&editpage6=&ibTabBottom6=&ibTabTop7=&editpage7=&ibTabBottom7=&ibTabTop8=&editpage8=&ibTabBottom8=&frm_p_t10sheet3_ofc_cd=&frm_p_t10sheet3_cnt_cd=&frm_p_t10sheet3_cust_seq=&frm_p_t10sheet3_ofc_cd_enable=&frm_p_t10sheet3_cust_seq_enable=&frm_p_t10sheet3_ofc_cnt_cd=&frm_c_t10sheet3_ofc_cd=&frm_c_t10sheet3_cnt_cd=&frm_c_t10sheet3_cust_seq=&frm_c_t10sheet3_ofc_cd_enable=&frm_c_t10sheet3_cust_seq_enable=&frm_c_t10sheet3_ofc_cnt_cd=&select_3rdPPD=&select_3rdCCT=&IBPREFIX=t10sheet1_&IBPREFIX=t10sheet2_&IBPREFIX=t10sheet3_&IBPREFIX=t10sheet4_&IBPREFIX=t10sheet5_&IBPREFIX=t10sheet6_&IBPREFIX=t10sheet7_&IBPREFIX=t10sheet8_&IBPREFIX=t10sheet9_',
        getParams: function(bl, off) {
            return this.params.replace("{BLNO}", bl)
        },
        bound: ['export', 'import']
    },
    history: {
        url: 'https://cntr.one-line.com/opuscntr/ESM_BKG_0566GS.do',
        params: "f_cmd=2&bkg_no={BKGNO}&bl_no={BLNO}",
        getParams: function(bl) {
            return this.params
                .replace('{BKGNO}', bl)
                .replace('{BLNO}', bl)
        },
        bound: ['export', 'import']
    },
    container: {
        url: 'https://cntr.one-line.com/opuscntr/ESM_BKG_0079_04GS.do',
        params: 'f_cmd=2&bkg_no=&bl_no=',
        bound: ['export', 'import']
    },
    blissue: {
        url: 'https://cntr.one-line.com/opuscntr/ESM_BKG_0079_09GS.do',
        params: 'f_cmd=2&bkg_no={BKGNO}&bl_no={BLNO}&setupfocoblflag&IBPREFIX=t11sheet1_&IBPREFIX=t11sheet2_&IBPREFIX=t11sheet3_&IBPREFIX=',
        getParams: function(bl) {
            return this.params
                .replace('{BKGNO}', bl)
                .replace('{BLNO}', bl)
        },
        bound: ['export', 'import']
    },
    outstandingInquiry: {
        url: 'https://cntr.one-line.com/opuscntr/STM_SAR_1001GS.do',
        params: "f_cmd=3&ots_ofc_cd={OFFICECODE}&cond_bl_no={BLNO}&stl_flg=ALL&ots_rt_flg=Y&ots_flg=Y",
        getParams: function(bl, off) {
            return this.params.replace("{OFFICECODE}", off).replace("{BLNO}", bl)
        },
        bound: ['export', 'import']
    },
    outstandingHistory: {
        url: 'https://cntr.one-line.com/opuscntr/STM_SAR_1003GS.do',
        params: 'f_cmd=3&rhq_cd=RICHQ&bl_no={BLNO}&inv_no=**********&bkg_no=&ots_ofc_cd={OFFICECODE}',
        getParams: function(bl, off) {
            return this.params.replace("{OFFICECODE}", off).replace("{BLNO}", bl)
        },
        goodException: function(v) {
            if (v == '') {
                return true
            }
            if (v.match(/errcode/i) != undefined) {
                return false
            }
        },
        bound: ['export', 'import']
    },
    invoiceInquiry: {
        url: "https://cntr.one-line.com/opuscntr/FNS_INV_0009GS.do",
        params: "f_cmd=2&login_ofc_cd={OFFICECODE}&pagetype=I&bl_src_no={BLNO}",
        getParams: function(bl, off) {
            return this.params.replace("{OFFICECODE}", off).replace("{BLNO}", bl)
        },
        bound: ['export', 'import']
    },
    eBkg_SIProcess: {
        url: "https://cntr.one-line.com/opuscntr/ESM_BKG_0228GS.do?ib_start_row=1&ib_end_row=1000",
        params: "f_cmd=2&usr_off_cd={OFFICECODE}&bkg_no={BLNO}",
        getParams: function(bl, off) {
            return this.params.replace("{OFFICECODE}", off).replace("{BLNO}", bl)
        },
        bound: ['export', 'import']
    },


    xhr: function(BL, transaction, Bound, off) {
        const Transaction = this.get(BL, transaction, Bound, off)
        if (Transaction.bound == -1) return !1
        return `new Promise((resolve, reject) => {
            var http = new XMLHttpRequest();
            var BL = "${BL}";
            var TransactionType = "${transaction}";
            var params = "${Transaction.params}";
            var Bound = "${Bound}";
            http.open('POST', "${Transaction.url}", true);
            http.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            http.onreadystatechange = function() { //Call a function when the state changes.
                if (http.readyState == 4 && http.status == 200) {
                    resolve({ BL: BL, Bound: Bound, TransactionType: TransactionType, data: http.responseText })
                } else if (http.readyState == 4 && http.status != 200) {
                    resolve({ BL: BL, Bound: Bound, TransactionType: TransactionType, error: { status: http.status, statusText: http.statusText } })
                }
            }
            http.onerror = function() { reject({ BL: BL, TransactionType: TransactionType, error: { status: "Unknown", statusText: "Http Error" } }) }
            http.send(params);
        })`
    }
}

const sleep = async(ms) => {
    await new Promise(resolve => setTimeout(() => {
        resolve("hi")
    }, ms));
}

function getOpusFields() {
    const settingsLoaded = (
        async function() {
            settings.load();
            while (settings.isloaded == false) {
                await sleep(500)
            }
            return settings.isloaded
        }
    )();
    console.log(settingsLoaded)
    settings
        .get()
        .then(allsettings => {
            OPUS_INTERVAL = Number(allsettings[0].data.intervals.opus)
            opusFieldMap = allsettings[1].data
            console.log('Got OpusFields')
            settings.close()
        })
}

const noDataFound = new RegExp(
    /No data found.|Failed to find Booking|<ERROR>/,
    'gi'
)

function clearSchedule() {
    clearInterval(theInterval);
    console.log("Interval cleared. Please re-load the page to restart the interval")
    return;
}

onload = () => {


    function setSchedule() {
        const secs = parseInt(OPUS_INTERVAL) * 60
        theInterval = setInterval(getOPUSdata, secs * 1000);
        console.log("Running at an interval of every " + secs + " seconds..!")
        return theInterval
    }

    showloader();

    ipcRenderer.on("fetch:Requested", () => {
        console.log("Received request from Fact to fetch data...Doing so right away!")
        if (FLAG_TRANSACTION_IN_PROGRESS) {
            return console.log("A Transaction was already being carried out. Rejecting this!")
        }
        getOPUSdata();
    })

    ipcRenderer.on("new:interval", (interval) => {
        OPUS_INTERVAL = newInterval;
        clearSchedule();
        setSchedule();
    })

    const loggedIn = state => {
        const status = state ? 'green' : 'red'
        ipcRenderer.send('login:status', {
            portal: 'opus',
            status: status
        })
    }

    webview.addEventListener('did-finish-load', () => {
        hideloader()

        const PageResults = `

        function a() {
            return {
                pathname: document.location.pathname
            }
        }; a();
        `
        webview
            .getWebContents()
            .executeJavaScript(PageResults)
            .then(pageResults => {
                if (
                    pageResults.pathname == 'about:blank' ||
                    pageResults.pathname == 'blank'
                ) {
                    loggedIn(false)
                    return GoToSignOnPage()
                } else if (pageResults.pathname == 'text/html,chromewebdata') {
                    loggedIn(false)
                    return showCitrixNotConnected(true)
                } else if (pageResults.pathname == '/opuscntr/SignOn.do') {
                    loggedIn(false)
                    showCitrixNotConnected(false)
                    return doSignOn()
                } else if (pageResults.pathname == '/opuscntr/MainPage.do') {
                    loggedIn(true)
                    if (!theInterval) setSchedule();
                    return getOPUSdata()
                }
            })
            .catch(err => {
                console.log(err)
            })
    });

    function showCitrixNotConnected(show) {
        const citElem = document.querySelector('.citrixNotConnected')
        if (show) {
            citElem.style.visibility = 'visible'
        } else {
            citElem.style.visibility = 'hidden'
        }
    }

    function LoadFactData() {
        if (fact.isloaded) { fact.manualDBLoad() } else { fact.load() }
        return fact
            .get({})
            .then(data => {
                return { data: data, error: null }
            })
            .catch(err => {
                return { error: err, data: null }
            })
    }

    function updateFACTItem(opusData) {
        return fact.update({ InvoiceNo: opusData.InvoiceNo }, { $set: { opus: opusData } }, {})
    }

    function getResponse(Code) {
        return webview.getWebContents().executeJavaScript(Code)
    }

    function addHTTPNetworkMonitor() {
        const monitorCode = `
        (function() {
            var oldOpen = XMLHttpRequest.prototype.open;
            window.openHTTPs = 0;
            XMLHttpRequest.prototype.open = function(method, url, async, user, pass) {
                window.openHTTPs++;
                this.addEventListener("readystatechange", function() {
                    if (this.readyState == 4) {
                        window.openHTTPs--;
                    }
                }, false);
                oldOpen.call(this, method, url, async, user, pass);
            }
        })(XMLHttpRequest);
        `
        return webview
            .getWebContents()
            .executeJavaScript(monitorCode)
            .then(s => {
                return s
            })
            .catch(err => {
                console.log(err)
            })
    }

    function getCleanElem(gibberish, of, bl, matchingKeyObj) {
        // Function to traverse thru the etc element and return a clean object
        function handleETC_TAG(dataNode, getDataFor) {
            // Return value willbe an object or key vlue pairs
            const etcObj = {}
            var childNodeValue
            for (var x = 0; x < getDataFor.length; x++) {
                try {
                    childNodeValue = dataNode.querySelector(
                        "ETC[KEY='" + getDataFor[x].opus_field + "']"
                    ).firstChild.nodeValue
                } catch (e) {
                    childNodeValue = ''
                }
                etcObj[getDataFor[x].formatted_field] = childNodeValue
            }

            return etcObj
        }

        function handleDATA_TAG(dataNode, fieldSet) {
            // Init an obj to return
            const retObj = { cols: [], data: [] }

            // Sometimes there will be no data in the DATA node
            if (dataNode == null || dataNode.attributes.length < 3) {
                return retObj
            }
            // Initialize the helper variables
            var col = dataNode.getAttribute('COLORDER')
            var colArr = col.split('|')
            var sep = dataNode.getAttribute('COLSEPARATOR')
            var dataChildNodes = dataNode.childNodes
            var row

            // Sometimes there will be col atributes but no data rows
            if (dataChildNodes == null) return retObj

            // Since we may or may not need all the columns, take out the ones which you need
            // Here we may replace the opus_field name with a propoer diplayable label
            fieldSet.forEach((field, idx) => {
                field.index = colArr.indexOf(field.opus_field)
                retObj.cols.push(field.formatted_field)
            })

            for (var i = 0; i < dataChildNodes.length; i++) {
                // Continue for text nodes
                if (dataChildNodes[i].nodeType != 1) continue
                    // Split the data row
                var arrData = dataChildNodes[i].firstChild.nodeValue.split(sep)
                    // Get data only for the columns which we need
                row = fieldSet.map((field, idx) => {
                    return arrData[field.index]
                })
                retObj.data.push(row)
            }
            // returns 1D arr of column headers and 2D arr of rows.
            return retObj
        }

        // Main function..
        // set the variables...
        const dataSplitter = '|$$|'
        gibberish = gibberish.split(dataSplitter)

        var parser,
            htmlDoc,
            children,
            child,
            nodeName,
            out = { BL: bl, TT: of },
            dataTag

        // Set the module
        out[of] = {}

        if (of == "outstandingHistory" || of == "outstandingInquiry") {
            console.log(of);
        }

        // This is a good way because we will only process "IF" the module requires data from
        // either ETC or DATA tag
        // Temp early exit because we dont have matching keys for all request types
        if (matchingKeyObj == undefined) return out;

        if (matchingKeyObj.hasOwnProperty('etctag')) {
            // Create the DOM element.. This will return the Sheet elem which contains ETC-DATA tag
            const ETCDoc = new DOMParser().parseFromString(gibberish[0], 'text/xml')
                // Get the ETC-DATA Tag
            const ETCNode = ETCDoc.getElementsByTagName('ETC-DATA').item(0)
                // Get data out of the ETC-DATA tag
            out[of].etctag = handleETC_TAG(ETCNode, matchingKeyObj.etctag)
        }

        if (matchingKeyObj.hasOwnProperty('datatag')) {
            const datatags = matchingKeyObj.datatag
                // This is also very efficient as we won't have to parse the Whole string as a DOM
                // And will only parse the needed tags
            datatags.forEach((dataTag, index) => {
                const DATATAG_NO = dataTag.no // Index of the DATA tag as represented in the whole string after split
                const TABLE_NAME = dataTag.tableName // Arbitary name to the table for proper referencing
                const DATADoc = new DOMParser().parseFromString(
                    gibberish[DATATAG_NO],
                    'text/xml'
                )
                const DATANode = DATADoc.getElementsByTagName('DATA').item(0) // This must be present
                out[of][TABLE_NAME] = handleDATA_TAG(DATANode, dataTag.fields)
            });
        }

        return out
    }

    ipcRenderer.on("signal:Wait", (e, signal) => {
        SIGNAL_TO_WAIT = signal
    });

    ipcRenderer.on("new:interval", function(event, newInterval) {
        OPUS_INTERVAL = newInterval;
        clearSchedule();
        setSchedule();
    })

    function setTransactionState(state) {
        FLAG_TRANSACTION_IN_PROGRESS = state
        ipcRenderer.send("signal:WaitForOpus", state)
    }

    async function getOPUSdata() {

        // May be this function already executed when the timer was triggered
        if (FLAG_TRANSACTION_IN_PROGRESS) {
            console.log("Returning because a transaction is already in process");
            return;
        };

        // Tell other trains to stop :D
        if (SIGNAL_TO_WAIT) {
            console.log("Have recd a Wait signal from the Main Process!")
            return;
        } else {
            setTransactionState(true)
        }

        const start = new Date().getTime()

        var factdata = await LoadFactData()

        if (factdata.error) {
            Logs.insert({
                timestamp: new Date().getTime(),
                activity: "Load Fact data",
                status: 'Fail',
                err: { message: factdata.error }
            })
            return setTransactionState(false)
        }

        // Since there will be difference in when FACT will download versus when Opus will be initiated
        // We want to skip items where data is already rectrieved
        // There will be a OPUS_IN_PROGRESS flag set to true to disallow the main process to update Firestore
        factdata = factdata.data.filter((factItem, idx) => {
            if (factItem.hasOwnProperty("opus") == false) return factItem;
        });

        const factLen = factdata.length

        // Simply return if nothing in fact file :)
        if (!factLen) {
            console.log("Fact log is empty, returning empty handed :(")
            setTransactionState(false)
            return;
        }

        console.log("Item count from FACT = " + factLen)

        const myrequests = Object.keys(requestor)
        const OpusDataHolder = {}
        let FACTItemsUpdated = 0
        const FACTItemsUpdateError = []
        let totalRequests = 0;
        let BLExplored;
        let response;
        let codes = [];

        let RequestMonitor = { BL: 0, Requests: 0, TotalFact: factLen, NotExim: 0 }
            // temp, put factlen back
        for (var bl, bound, office, z = 0; z < factLen; z++) {

            if (!factdata[z].Bound.match(/import|export/ig)) {
                RequestMonitor.NotExim++;
                continue;
            };

            RequestMonitor.BL++;
            bl = factdata[z]['BLNo'];
            bound = factdata[z].Bound;
            office = factdata[z].InvoiceNo.substring(0, 5)

            OpusDataHolder[bl] = { InvoiceNo: factdata[z].InvoiceNo }

            for (var code, x = 0; x < myrequests.length; x++) {
                if (myrequests[x].match('xhr|get') != undefined) continue;
                code = requestor.xhr(bl, myrequests[x], bound, office);
                if (code) codes.push(code)
            }
        }

        totalRequests = RequestMonitor.Requests = codes.length;

        codes.forEach((code, index) => {

            response = getResponse(code);

            response.then(resp => {
                totalRequests -= 1;
                console.log("Responses received")
                CleanUpOpusData(resp).then(CD => {
                    OpusDataHolder[CD.BL][CD.TT] = JSON.stringify(CD[CD.TT])
                }).catch(e => {
                    console.log(e)
                })
            }).catch(err => {
                totalRequests -= 1;
                console.log("Responses received")
                console.log(err)
            })

        });

        console.log("Total Requests: " + RequestMonitor.Requests + ", Total BL: " + RequestMonitor.BL, ", Total From Fact: " + RequestMonitor.TotalFact + ", Not Exim: " + RequestMonitor.NotExim)

        const requestCompletedTimer = setInterval(() => {

            if (totalRequests == 0) {

                const end = new Date().getTime()
                console.log(OpusDataHolder)
                BLExplored = Object.keys(OpusDataHolder);

                const factUpdatedTimer = setInterval(() => {
                    if (BLExplored.length == (FACTItemsUpdateError.length + FACTItemsUpdated)) {
                        updateOpusLog(BLExplored.length, FACTItemsUpdated, FACTItemsUpdateError, totalRequests, start, end).then(() => {
                            clearInterval(factUpdatedTimer);
                            console.log("Fact Items updated in Fact db")
                            fact.compact();
                            setTransactionState(false)
                            ipcRenderer.send("tell:opusFetchedData", BLExplored.length);
                        });
                    } else {
                        console.log("Still updating fact items")
                    }
                }, 500)

                // Update fact items
                for (var z = 0; z < BLExplored.length; z++) {
                    updateFACTItem(OpusDataHolder[BLExplored[z]]).then(bl => {
                        console.log('Fact item updated')
                        FACTItemsUpdated += 1
                    }).catch((err, bl) => {
                        console.log('Fact item update error')
                        FACTItemsUpdateError.push(err)
                    })
                }
                clearInterval(requestCompletedTimer);
            }
        }, 500)
    };

    function updateOpusLog(totalBL, itemsUpdated, updateError, total, whenStarted, whenEnded) {
        return Logs.insert({
            timestamp: whenStarted,
            ended: whenEnded,
            status: "Success",
            activity: "Get Opus data",
            totalRequests: total,
            totalBL: totalBL,
            itemsUpdated: itemsUpdated,
            err: updateError
        });
    }

    function CleanUpOpusData(UncleanOpusResponse) {
        const _BL = UncleanOpusResponse.BL,
            _TT = UncleanOpusResponse.TransactionType,
            _Data = UncleanOpusResponse.data,
            _FieldMap = opusFieldMap[_TT]

        return new Promise((resolve, reject) => {
            try {
                const CleanData = getCleanElem(_Data, _TT, _BL, _FieldMap)
                resolve(CleanData)
            } catch (e) {
                reject(e.message)
            }
        })
    }

    function doSignOn() {
        console.log('Signing in')

        B.creds.get({ App: "Opus" }).then(cred => {
            if (!cred) return provideCreds();
            const login = `
                document.getElementById("j_username").value = '${cred.Id}'; document.getElementById("j_password").value = '${cred.Pwd}'; document.querySelector(".login_btn").click();
            `
            return webview
                .getWebContents()
                .executeJavaScript(login)
                .then(() => {
                    ipcRenderer.send('login:status', {
                            portal: 'opus',
                            status: 'green'
                        })
                        //return navigateToMainPage();
                })
                .catch(err => {
                    console.log('login error')
                })
        })
    }

    function provideCreds() {
        var RP = path.join(resourcesPath, "OpusLogin.html"),
            DTG = path.join(resourcesPath, "SetCredentials.html#opus")
        document.location.href = DTG + `?App=Opus;ComingFrom=Opus;RP=${RP};Al=true`
    }

    function GoToSignOnPage() {
        showloader()
        const mainpage = 'https://cntr.one-line.com/opuscntr/SignOn.do'
        return webview
            .getWebContents()
            .executeJavaScript(
                `
                                document.location.href = "${mainpage}"
                                `
            )
            .then(s => {
                console.log(s)
            })
            .catch(err => {
                console.log(err)
            })
    }

    setTimeout(() => {
        if (!isloaderHidden()) {
            const setlocationToBlank = `document.location.href="about:blank"`
            webview.getWebContents().executeJavaScript(setlocationToBlank).then(() => {
                console.log("Force location setting to blank");
            })
        }
    }, 5000)
}